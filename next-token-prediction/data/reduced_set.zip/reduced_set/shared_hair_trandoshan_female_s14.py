from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/hair/trandoshan/shared_hair_trandoshan_female_s14.iff"
	result.attribute_template_id = -1
	result.stfName("hair_name","ridges")		
	return result