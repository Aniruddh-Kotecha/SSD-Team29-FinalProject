import gc
from eliot.testing import capture_logging
from .._defer import gather_deferreds
from ...testtools import TestCase
from twisted.internet.defer import fail, FirstError, succeed, Deferred
from twisted.python.failure import Failure
class GatherDeferredsTests(TestCase):
    @capture_logging(None)
    def test_logging(self, logger):
        expected_failure1 = Failure(ZeroDivisionError('test_logging1'))
        expected_failure2 = Failure(ZeroDivisionError('test_logging2'))
        self.failureResultOf(
            gather_deferreds(
                [fail(expected_failure1), fail(expected_failure2)]
            )
        )
        failures = logger.flush_tracebacks(ZeroDivisionError)
        self.assertEqual(
            [expected_failure1.value, expected_failure2.value],
            list(
                failure["reason"]
                for failure
                in failures
            )
        )
    @capture_logging(None)
    def test_errors_logged_immediately(self, logger):
        d1 = Deferred()
        d2 = Deferred()
        gathering = gather_deferreds([d1, d2])
        expected_error = ZeroDivisionError()
        d1.errback(expected_error)
        logged_errors = logger.flush_tracebacks(ZeroDivisionError)
        self.assertEqual(
            [expected_error],
            list(f["reason"] for f in logged_errors),
        )
        d2.callback(None)
        self.failureResultOf(gathering)
    def test_success(self):
        expected_result1 = object()
        expected_result2 = object()
        d = gather_deferreds(
            [succeed(expected_result1), succeed(expected_result2)])
        results = self.successResultOf(d)
        self.assertEqual([expected_result1, expected_result2], results)
    @capture_logging(
        lambda self, logger: logger.flush_tracebacks(ZeroDivisionError)
    )
    def test_first_error(self, logger):
        d = gather_deferreds(
            [succeed('SUCCESS1'),
             fail(ZeroDivisionError('failure1')),
             succeed('SUCCESS2')])
        self.failureResultOf(d, FirstError)
    @capture_logging(
        lambda self, logger: logger.flush_tracebacks(ZeroDivisionError)
    )
    def test_first_error_value(self, logger):
        failure1 = Failure(ZeroDivisionError('failure1'))
        failure2 = Failure(ZeroDivisionError('failure1'))
        d = gather_deferreds([fail(failure1), succeed(None), fail(failure2)])
        first_error = self.failureResultOf(d, FirstError)
        self.assertIs(first_error.value.subFailure, failure1)
    @capture_logging(
        lambda self, logger: logger.flush_tracebacks(ZeroDivisionError)
    )
    def test_fire_when_all_fired(self, logger):
        d1 = Deferred()
        d2 = Deferred()
        d3 = Deferred()
        gathering = gather_deferreds([d1, d2, d3])
        d2.errback(ZeroDivisionError('test_consume_errors1'))
        self.assertNoResult(gathering)
        d1.callback(None)
        d3.callback(None)
        self.failureResultOf(gathering)
    @capture_logging(None)
    def test_consume_errors(self, logger):
        d1 = fail(ZeroDivisionError())
        d2 = succeed(None)
        d3 = fail(ZeroDivisionError())
        self.failureResultOf(gather_deferreds([d1, d2, d3]))
        logger.flush_tracebacks(ZeroDivisionError)
        del d1, d2, d3
        gc.collect()
        self.assertEqual([], logger.flush_tracebacks(ZeroDivisionError))