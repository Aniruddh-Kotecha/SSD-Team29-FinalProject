from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/graul/shared_lair_graul.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","graul")		
	return result