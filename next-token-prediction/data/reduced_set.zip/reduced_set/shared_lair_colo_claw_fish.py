from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/colo_claw_fish/shared_lair_colo_claw_fish.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","colo_claw_fish")		
	return result