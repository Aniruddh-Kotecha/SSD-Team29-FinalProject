from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/swirl_prong/shared_lair_swirl_prong_grassland.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","swirl_prong_grassland")		
	return result