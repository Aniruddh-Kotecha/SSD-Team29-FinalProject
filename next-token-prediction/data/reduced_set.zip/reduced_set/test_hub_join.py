import gevent
res = gevent.get_hub().join()
assert res is True, res
res = gevent.get_hub().join()
assert res is True, res
gevent.sleep(0.01)
res = gevent.get_hub().join()
assert res is True, res