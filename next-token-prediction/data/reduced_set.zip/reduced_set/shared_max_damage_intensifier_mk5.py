from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/crafted/weapon/shared_max_damage_intensifier_mk5.iff"
	result.attribute_template_id = 8
	result.stfName("space_crafting_n","max_damage_intensifier_mk5")		
	return result