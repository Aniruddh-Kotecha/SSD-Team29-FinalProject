from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/attachment/wing/shared_lambda_wing_r.iff"
	result.attribute_template_id = 8
	result.stfName("item_n","ship_attachment")		
	return result