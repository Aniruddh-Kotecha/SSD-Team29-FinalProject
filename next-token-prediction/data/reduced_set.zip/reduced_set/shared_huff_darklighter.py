from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_huff_darklighter.iff"
	result.attribute_template_id = 9
	result.stfName("theme_park_name","base_npc_theme_park")		
	return result