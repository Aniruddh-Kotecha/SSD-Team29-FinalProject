from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_mullud_bombo.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","mullud_bombo")		
	return result