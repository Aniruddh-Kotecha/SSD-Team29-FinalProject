from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/hair/human/shared_hair_human_female_s04.iff"
	result.attribute_template_id = -1
	result.stfName("hair_name","hair")		
	return result