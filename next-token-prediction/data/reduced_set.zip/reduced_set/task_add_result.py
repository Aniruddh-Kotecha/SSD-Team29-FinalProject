from msrest.serialization import Model
class TaskAddResult(Model):
    _validation = {
        'status': {'required': True},
        'task_id': {'required': True},
    }
    _attribute_map = {
        'status': {'key': 'status', 'type': 'TaskAddStatus'},
        'task_id': {'key': 'taskId', 'type': 'str'},
        'e_tag': {'key': 'eTag', 'type': 'str'},
        'last_modified': {'key': 'lastModified', 'type': 'iso-8601'},
        'location': {'key': 'location', 'type': 'str'},
        'error': {'key': 'error', 'type': 'BatchError'},
    }
    def __init__(self, status, task_id, e_tag=None, last_modified=None, location=None, error=None):
        self.status = status
        self.task_id = task_id
        self.e_tag = e_tag
        self.last_modified = last_modified
        self.location = location
        self.error = error