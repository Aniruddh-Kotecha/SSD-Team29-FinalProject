import os
import numpy as np
import numpy.testing as npt
import numpy.testing.decorators as dec
from scipy.signal import signaltools
from scipy import fftpack
import nitime
from nitime import algorithms as tsa
from nitime import utils as ut
test_dir_path = os.path.join(nitime.__path__[0], 'tests')
def test_scipy_resample():
    freq_list = np.random.randint(0, high=15, size=5)
    a = [np.sin(2 * np.pi * f * np.linspace(0, 1, 64, endpoint=False))
         for f in freq_list]
    tst = np.array(a).sum(axis=0)
    t_up = signaltools.resample(tst, 128)
    np.testing.assert_array_almost_equal(t_up[::2], tst)
    t_dn = signaltools.resample(tst, 32)
    np.testing.assert_array_almost_equal(t_dn, tst[::2])
    dn_samp_ana = np.array([np.sin(2 * np.pi * f * np.linspace(0, 1, 48, endpoint=False))
                            for f in freq_list]).sum(axis=0)
    t_dn2 = signaltools.resample(tst, 48)
    npt.assert_array_almost_equal(t_dn2, dn_samp_ana)
def test_dpss_windows():
    "Are the eigenvalues representing spectral concentration near unity"
    _, l = tsa.dpss_windows(31, 6, 4)
    unos = np.ones(4)
    npt.assert_array_almost_equal(l, unos)
    _, l = tsa.dpss_windows(31, 7, 4)
    npt.assert_array_almost_equal(l, unos)
    _, l = tsa.dpss_windows(31, 8, 4)
    npt.assert_array_almost_equal(l, unos)
    _, l = tsa.dpss_windows(31, 8, 4.2)
    npt.assert_array_almost_equal(l, unos)
def test_dpss_matlab():
    a, _ = tsa.dpss_windows(100, 2, 4)
    b = np.loadtxt(os.path.join(test_dir_path, 'dpss_matlab.txt'))
    npt.assert_almost_equal(a, b.T)
def test_periodogram():
    arsig, _, _ = ut.ar_generator(N=512)
    avg_pwr = (arsig * arsig.conjugate()).mean()
    f, psd = tsa.periodogram(arsig, N=2048)
    df = 2. * np.pi / 2048
    avg_pwr_est = np.trapz(psd, dx=df)
    npt.assert_almost_equal(avg_pwr, avg_pwr_est, decimal=1)
def permutation_system(N):
    p = np.zeros((N, N))
    targets = list(range(N))
    for i in range(N):
        popper = np.random.randint(0, high=len(targets))
        j = targets.pop(popper)
        p[i, j] = 1
    return p
def test_boxcar_filter():
    a = np.random.rand(100)
    b = tsa.boxcar_filter(a)
    npt.assert_equal(a, b)
    a = np.random.rand(99)
    b = tsa.boxcar_filter(a)
    npt.assert_equal(a, b)
    b = tsa.boxcar_filter(a, ub=0.25)
    npt.assert_equal(a.shape, b.shape)
    b = tsa.boxcar_filter(a, lb=0.25)
    npt.assert_equal(a.shape, b.shape)
def test_get_spectra():
    t = np.linspace(0, 16 * np.pi, 2 ** 10)
    x = (np.sin(t) + np.sin(2 * t) + np.sin(3 * t) +
         0.1 * np.random.rand(t.shape[-1]))
    NFFT = 64
    N = x.shape[-1]
    f_welch = tsa.get_spectra(x, method={'this_method': 'welch', 'NFFT': NFFT})
    f_periodogram = tsa.get_spectra(x, method={'this_method': 'periodogram_csd'})
    f_multi_taper = tsa.get_spectra(x, method={'this_method': 'multi_taper_csd'})
    npt.assert_equal(f_welch[0].shape, (NFFT // 2 + 1,))
    npt.assert_equal(f_periodogram[0].shape, (N // 2 + 1,))
    npt.assert_equal(f_multi_taper[0].shape, (N // 2 + 1,))
    x = np.reshape(x, (2, x.shape[-1] // 2))
    N = x.shape[-1]
    NFFT = 64
    f_welch = tsa.get_spectra(x, method={'this_method': 'welch', 'NFFT': NFFT})
    f_periodogram = tsa.get_spectra(x, method={'this_method': 'periodogram_csd'})
    f_multi_taper = tsa.get_spectra(x, method={'this_method': 'multi_taper_csd'})
    npt.assert_equal(f_welch[0].shape[0], NFFT / 2 + 1)
    npt.assert_equal(f_periodogram[0].shape[0], N / 2 + 1)
    npt.assert_equal(f_multi_taper[0].shape[0], N / 2 + 1)
def test_psd_matlab():
    from matplotlib import mlab
    test_dir_path = os.path.join(nitime.__path__[0], 'tests')
    ts = np.loadtxt(os.path.join(test_dir_path, 'tseries12.txt'))
    ts0 = ts[1] + ts[0] * np.complex(0, 1)
    NFFT = 256
    Fs = 1.0
    noverlap = NFFT / 2
    fxx, f = mlab.psd(ts0, NFFT=NFFT, Fs=Fs, noverlap=noverlap,
                      scale_by_freq=True)
    fxx_mlab = fftpack.fftshift(fxx).squeeze()
    fxx_matlab = np.loadtxt(os.path.join(test_dir_path, 'fxx_matlab.txt'))
    npt.assert_almost_equal(fxx_mlab, fxx_matlab, decimal=5)
@dec.slow
def test_long_dpss_win():
    a1,e = tsa.dpss_windows(166800, 4, 8, interp_from=4096)
    a2,e = tsa.dpss_windows(166800, 4, 8)
    npt.assert_almost_equal(a1, a2, decimal=5)
    test_dir_path = os.path.join(nitime.__path__[0], 'tests')
    matlab_long_dpss = np.load(os.path.join(test_dir_path, 'long_dpss_matlab.npy'))
    npt.assert_almost_equal(a1[0], matlab_long_dpss, decimal=5)
    npt.assert_almost_equal(a1[0], matlab_long_dpss, decimal=5)