import argparse
import re
import subprocess
import maas_common
class ParseError(maas_common.MaaSException):
    pass
class CommandNotRecognized(maas_common.MaaSException):
    pass
def recon_output(for_ring, options=None):
    command = ['swift-recon', for_ring]
    command.extend(options or [])
    out = subprocess.check_output(command)
    return filter(lambda s: s and not s.startswith(('==', '-')),
                  out.split('\n'))
def stat_regexp_generator(data):
    expression = 
    return re.compile('\[' + data + '\]' + expression, re.VERBOSE)
def _parse_into_dict(line, parsed_by):
    match = parsed_by.match(line)
    if match:
        return match.groupdict()
    else:
        raise ParseError("Cannot parse '{0}' for statistics.".format(line))
def recon_stats_dicts(for_ring, options, starting_with, parsed_by):
    return map(lambda l: _parse_into_dict(l, parsed_by),
               filter(lambda s: s.startswith(starting_with),
                      recon_output(for_ring, options)))
def swift_replication(for_ring):
    regexp = stat_regexp_generator(r'replication_(?P<replication_type>\w+)')
    replication_dicts = recon_stats_dicts(for_ring, ['-r'], '[replication_',
                                          regexp)
    replication_statistics = {}
    for rep_dict in replication_dicts:
        replication_statistics[rep_dict.pop('replication_type')] = rep_dict
    return replication_statistics
def swift_async():
    regexp = stat_regexp_generator('async_pending')
    async_dicts = recon_stats_dicts('object', ['-a'], '[async_pending]',
                                    regexp)
    stats = {}
    for async_dict in async_dicts:
        if async_dict:
            stats = async_dict
            break
    else:
        maas_common.status_err(
            'No data could be collected about pending async operations'
        )
    return {'async': stats}
def swift_quarantine():
    regexp = stat_regexp_generator('quarantined_(?P<ring>\w+)')
    quarantined_dicts = recon_stats_dicts('-q', [], '[quarantined_',
                                          regexp)
    quarantined_statistics = {}
    for quar_dict in quarantined_dicts:
        quarantined_statistics[quar_dict.pop('ring')] = quar_dict
    return quarantined_statistics
def swift_md5():
    check_re = re.compile('Checking\s+(?P<check>[^\s]+)\s+md5sums?')
    error_re = re.compile('https?://(?P<address>[^:]+):\d+')
    result_re = re.compile(
        '(?P<success>\d+)/(?P<total>\d+)[^\d]+(?P<errors>\d+).*'
    )
    output = recon_output('--md5')
    md5_statistics = {}
    checking_dict = {}
    for line in output:
        check_match = check_re.search(line)
        if check_match and not checking_dict:
            checking_dict = check_match.groupdict()
            continue
        if line.startswith('!!'):
            error_dict = error_re.search(line).groupdict()
            maas_common.status_err('md5 mismatch for {0} on host {1}'.format(
                checking_dict.get('check'), error_dict['address']
            ))
        results_match = result_re.match(line)
        if results_match:
            check_name = checking_dict['check'].replace('.', '_')
            md5_statistics[check_name] = results_match.groupdict()
            checking_dict = {}
    return md5_statistics
def print_nested_stats(statistics):
    for ring, stats in statistics.items():
        print_stats(ring, stats)
metrics_per_stat = {
    'avg': lambda name, val: maas_common.metric(name, 'double', val),
    'failed': lambda name, val: maas_common.metric(name, 'double', val[:-1])
}
DEFAULT_METRIC = lambda name, val: maas_common.metric(name, 'uint64', val)
def print_stats(prefix, statistics):
    for name, value in statistics.items():
        metric = metrics_per_stat.get(name, DEFAULT_METRIC)
        metric('{0}_{1}'.format(prefix, name), value)
def make_parser():
    parser = argparse.ArgumentParser(
        description='Process and print swift-recon statistics'
    )
    parser.add_argument('recon',
                        help='Which statistics to collect. Acceptable recon: '
                             '"async-pendings", "md5", "quarantine", '
                             '"replication"')
    parser.add_argument('--ring-type', dest='ring',
                        help='Which ring to run statistics for. Only used by '
                             'replication recon.')
    return parser
def get_stats_from(args):
    stats = {}
    if args.recon == 'async-pendings':
        stats = swift_async()
    elif args.recon == 'md5':
        stats = swift_md5()
    elif args.recon == 'quarantine':
        stats = swift_quarantine()
    elif args.recon == 'replication':
        if args.ring not in {"account", "container", "object"}:
            maas_common.status_err('no ring provided to check')
        stats = swift_replication(args.ring)
    else:
        raise CommandNotRecognized('unrecognized command "{0}"'.format(
            args.recon))
    return stats
def main():
    parser = make_parser()
    args = parser.parse_args()
    try:
        stats = get_stats_from(args)
    except (ParseError, CommandNotRecognized) as e:
        maas_common.status_err(str(e))
    if stats:
        maas_common.status_ok()
        print_nested_stats(stats)
if __name__ == '__main__':
    with maas_common.print_output():
        main()