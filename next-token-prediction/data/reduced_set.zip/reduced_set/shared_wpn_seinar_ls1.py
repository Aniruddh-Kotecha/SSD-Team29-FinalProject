from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/weapon/shared_wpn_seinar_ls1.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","wpn_seinar_ls1_n")		
	return result