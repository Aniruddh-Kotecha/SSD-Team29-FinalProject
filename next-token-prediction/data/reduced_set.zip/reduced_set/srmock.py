from falcon import util
class StartResponseMock(object):
    def __init__(self):
        self._called = 0
        self.status = None
        self.headers = None
        self.exc_info = None
    def __call__(self, status, headers, exc_info=None):
        self._called += 1
        self.status = status
        self.headers = [(name.lower(), value) for name, value in headers]
        self.headers_dict = util.CaseInsensitiveDict(headers)
        self.exc_info = exc_info
    @property
    def call_count(self):
        return self._called