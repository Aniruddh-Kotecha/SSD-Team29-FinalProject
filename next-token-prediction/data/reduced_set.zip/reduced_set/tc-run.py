from __future__ import division
import argparse
import os
import time
import threading
import Queue
import cv2
import numpy as np
from tc_common import *
job_name = ''
start_frame = 0
end_frame = 0
frames_count = 0
current_frame = 0
capture_direction = 1
capture_ext = 'png'
fileSaveParams = []
def parse_commandline():
    global job_name, start_frame, end_frame, frames_count
    global current_frame, capture_direction, capture_ext, reverse, brackets
    parser = argparse.ArgumentParser()
    parser.add_argument('jobname', help='Name of the telecine job')
    parser.add_argument('-s','--start', type=int, help='Start frame number')
    parser.add_argument('-e','--end', type=int, help='End frame number')
    parser.add_argument('-j','--jpeg', help='Save Jpeg images',	action='store_true')
    parser.add_argument('-r','--reverse', help='Run backwards', action='store_true')
    parser.add_argument('-b','--brackets', help='Bracket exposures', action='store_true')
    args = parser.parse_args()
    job_name = sanitise_job_name(args.jobname)
    start_frame = args.start if args.start else 0
    end_frame = args.end if args.end else 0
    frames_count = abs(end_frame - start_frame)+1
    if frames_count==0:
	print('Job needs to know how many frames')
	quit()
    capture_direction = 1 if end_frame > start_frame else -1
    current_frame = start_frame
    if args.jpeg:
	print('Saving as jpeg')
	capture_ext = 'jpg'
	fileSaveParams = [int(cv2.IMWRITE_JPEG_QUALITY), 95]
    brackets = args.brackets
    if args.brackets:
	print('Bracketing on')
    reverse = args.reverse
    if args.reverse:
	print('Reverse capture')
def make_crop():
    cx,cy = pf.centre
    crop_x = cx+cnf.crop_offset[0]
    crop_y = cy+cnf.crop_offset[1]
    return pf.cropToSlice( (crop_x, crop_y, cnf.crop_size[0],cnf.crop_size[1]) )
q = Queue.Queue(10)
job_finished = False
still_writing = True
def writer():
    global q, job_finished, still_writing
    write_time = Stopwatch()
    while not job_finished:
	still_writing = True
	while not q.empty():
	    write_time.start()
            fn,img = q.get()
	    try:
                cv2.imwrite(fn,img, fileSaveParams)
                t=write_time.stop()
                print('Written {} in {:.02f} secs'.format(fn,t))
	    except:
		t=write_time.stop()
		print('Failed to write {} in {:.02f} secs'.format(fn,t))
    still_writing = False
failed_frames = 0
taking_time = Stopwatch()
taking_times = []
def single_picture(current_frame):
    global cnf, capture_ext,fpath,failed_frames
    global taking_time, taking_times
    fname = 'img-{:05d}.{}'.format(current_frame,capture_ext)
    taking_time.start()
    img = cam.take_picture()
    t = taking_time.stop()
    taking_times.append(t)
    print('Taken {} in {:.2f} secs'.format(current_frame,t))
    if cnf.show_gray:
	img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    pf.find(img)
    found = pf.found
    if not found:
	print('Perforation failed:{}'.format(fname))
	failed_frames += 1
	failedname = 'failed-' + fname
	failedname = os.path.join( fpath, failedname )
	q.put( (failedname,img) )
	if pf.position != (0,0):
	    found = True
    else:
	failed_frames = 0
    if found:
	img = img[make_crop()]
	fname = os.path.join(fpath,fname)
	q.put( (fname,img) )
def bracket_pictures(current_frame):
    global cnf, capture_ext,fpath,failed_frames
    global taking_time, taking_times
    fnames = [ 'img-{:05d}-1.{}'.format(current_frame,capture_ext),\
	       'img-{:05d}-2.{}'.format(current_frame,capture_ext) ]
    taking_time.start()
    imgs = cam.take_bracket_pictures()
    t = taking_time.stop()
    taking_times.append(t)
    print('Taken {} in {:.2f} secs'.format(current_frame,t))
    if cnf.show_gray:
	imgs[0] = cv2.cvtColor(imgs[0],cv2.COLOR_BGR2GRAY)
	imgs[1] = cv2.cvtColor(imgs[1],cv2.COLOR_BGR2GRAY)
    pf.find(imgs[0])
    found = pf.found
    if not found:
	print('Perforation failed:{}'.format(fnames[0]))
	failed_frames += 1
	failednames = [ os.path.join( fpath, ('failed-' + fnames[0]) ), \
			os.path.join( fpath, ('failed-' + fnames[1]) ) ]
	q.put( (failednames[0],imgs[0]) )
	q.put( (failednames[1],imgs[1]) )
	if pf.position != (0,0):
	    found = True
    else:
	failed_frames = 0
    if found:
	imgs[0] = imgs[0][make_crop()]
	imgs[1] = imgs[1][make_crop()]
	fnames = [ os.path.join(fpath,fnames[0]), os.path.join(fpath,fnames[1]) ]
	q.put( (fnames[0],imgs[0]) )
	q.put( (fnames[1],imgs[1]) )
def run_job():
    global q, job_finished
    global cnf,job_name, start_frame, end_frame 
    global capture_direction, capture_ext, fpath
    global brackets, reverse
    global pf, tc, cam
    global failed_frames
    max_fails = 5
    job_time = Stopwatch()
    job_time.start()
    job_finished = False
    t = threading.Thread(target=writer)
    t.start()
    print('Film type: {}'.format(pf.filmType))
    try:
	tc.light_on()
	cam.setup_cam(cnf.awb_gains, cnf.shutter_speed, cnf.drc, cnf.image_effect)
	centre_frame()
	frame_time = Stopwatch()
	frame_times = []
	end_frame = end_frame + capture_direction	
	for current_frame in range(start_frame,end_frame,capture_direction):
	    frame_time.start()
	    taking_time.start()
	    if not brackets:
		single_picture(current_frame)
	    else:
		bracket_pictures(current_frame)
	    if failed_frames >= max_fails:
		print('Maximum failed perforation detections')
		break
	    if not reverse:
	    	next_frame()
	    else:
	    	prev_frame()
	    t = frame_time.stop()
	    print('Frame {} in {:.2f} secs'.format(current_frame, t))
	    frame_times.append(t)
    finally:
	tc.light_off()
	cam.close()
	job_finished = True	
	while still_writing:
	    time.sleep(0.1)
    jt = job_time.stop()
    minutes = jt // 60
    seconds = jt % 60
    job_finished = True		
    ave_per_frame = sum(frame_times) / len(frame_times)
    ave_camera_time = sum(taking_times) / len(taking_times)
    print('%d frames'%(len(frame_times)))
    print('Elapsed time {:.0f} mins {:.1f} secs'.format(minutes,seconds))
    print('Average time per frame: {:.2f} secs'.format(ave_per_frame))
    print('Fastest frame: {:.2f} secs'.format(min(frame_times)))
    print('Slowest frame: {:.2f} secs'.format(max(frame_times)))
    print('Average camera time per frame: {:.2f} secs'.format(ave_camera_time))
    print('Fastest frame: {:.2f} secs'.format(min(taking_times)))
    print('Slowest frame: {:.2f} secs'.format(max(taking_times)))
if __name__ == '__main__':
    parse_commandline()
    cnf.read_configfile(job_name)
    brackets = brackets or cnf.brackets
    pf.init( filmType=cnf.film_type, imageSize=cam.MAX_IMAGE_RESOLUTION,
                    expectedSize=cnf.perf_size, cx=cnf.perf_cx )
    try:
	pf.setROI()
    except:
	print "Cannot set ROI - run setup and select a perforation"
	quit()
    print('Job:%s  %d-%d : %d frames'%(job_name,start_frame,end_frame,frames_count))
    print('Shutter speed: %d gain_r:%.3f gain_b:%.3f'%(cnf.shutter_speed,cnf.awb_gains[0],cnf.awb_gains[1]) )
    print('cx:{} Perf size:{}'.format(pf.centre[0],pf.expectedSize)) 
    print('Crop: %d:%d %dx%d'%(cnf.crop_offset[0],cnf.crop_offset[1],cnf.crop_size[0],cnf.crop_size[1]))
    if capture_direction > 0:
	print('Counting Forwards')
    else:
	print('Counting Backwards')
    fpath = os.path.join('.',job_name)
    if not os.path.exists(fpath):
	try:
	    os.mkdir(fpath)
	except:
	    print('Error creating capture directory: %s'%fpath)
	    quit()
    if not os.path.isdir(fpath):
	print('%s is a file not a directory'%fpath)
	quit()
    run_job()