from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/military/shared_outpost_cloning_facility.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","cloning_facility")		
	return result