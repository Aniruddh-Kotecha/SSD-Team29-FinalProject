from pandas.sparse.series import SparseSeries
from pandas.sparse.frame import SparseDataFrame
from pandas.sparse.panel import SparsePanel