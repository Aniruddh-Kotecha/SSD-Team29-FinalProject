import signal
from desktop.lib.thread_util import dump_traceback
def dump_threads_on_sigquit(signum, frame):
  dump_traceback()
signal.signal(signal.SIGUSR1, dump_threads_on_sigquit)