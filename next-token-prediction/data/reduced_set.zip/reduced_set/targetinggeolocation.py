from facebookads.adobjects.abstractobject import AbstractObject
class TargetingGeoLocation(
    AbstractObject,
):
    def __init__(self, api=None):
        super(TargetingGeoLocation, self).__init__()
        self._isTargetingGeoLocation = True
        self._api = api
    class Field(AbstractObject.Field):
        cities = 'cities'
        countries = 'countries'
        country_groups = 'country_groups'
        custom_locations = 'custom_locations'
        electoral_districts = 'electoral_districts'
        geo_markets = 'geo_markets'
        location_types = 'location_types'
        places = 'places'
        regions = 'regions'
        zips = 'zips'
    _field_types = {
        'cities': 'list<TargetingGeoLocationCity>',
        'countries': 'list<string>',
        'country_groups': 'list<string>',
        'custom_locations': 'list<TargetingGeoLocationCustomLocation>',
        'electoral_districts': 'list<Object>',
        'geo_markets': 'list<TargetingGeoLocationMarket>',
        'location_types': 'list<string>',
        'places': 'list<TargetingGeoLocationPlace>',
        'regions': 'list<TargetingGeoLocationRegion>',
        'zips': 'list<TargetingGeoLocationZip>',
    }
    @classmethod
    def _get_field_enum_info(cls):
        field_enum_info = {}
        return field_enum_info