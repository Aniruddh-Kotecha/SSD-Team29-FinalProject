from twilio.rest.resources.util import normalize_dates, parse_date
from twilio.rest.resources import InstanceResource, ListResource
class ShortCode(InstanceResource):
    def update(self, **kwargs):
        return self.parent.update(self.name, **kwargs)
class ShortCodes(ListResource):
    name = "ShortCodes"
    key = "short_codes"
    instance = ShortCode
    def list(self, **kwargs):
        return self.get_instances(kwargs)
    def update(self, sid, url=None, method=None, fallback_url=None,
               fallback_method=None, **kwargs):
        kwargs["sms_url"] = kwargs.get("sms_url", url)
        kwargs["sms_method"] = kwargs.get("sms_method", method)
        kwargs["sms_fallback_url"] = \
            kwargs.get("sms_fallback_url", fallback_url)
        kwargs["sms_fallback_method"] = \
            kwargs.get("sms_fallback_method", fallback_method)
        return self.update_instance(sid, kwargs)
class Sms(object):
    name = "SMS"
    key = "sms"
    def __init__(self, base_uri, auth):
        self.uri = "%s/SMS" % base_uri
        self.messages = SmsMessages(self.uri, auth)
        self.short_codes = ShortCodes(self.uri, auth)
class SmsMessage(InstanceResource):
    pass
class SmsMessages(ListResource):
    name = "Messages"
    key = "sms_messages"
    instance = SmsMessage
    def create(self, from_=None, **kwargs):
        kwargs["from"] = from_
        return self.create_instance(kwargs)
    @normalize_dates
    def list(self, from_=None, before=None, after=None, date_sent=None, **kw):
        kw["From"] = from_
        kw["DateSent<"] = before
        kw["DateSent>"] = after
        kw["DateSent"] = parse_date(date_sent)
        return self.get_instances(kw)