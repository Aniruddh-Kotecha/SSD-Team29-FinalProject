from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/loot/misc/shared_corsec_id_badge.iff"
	result.attribute_template_id = -1
	result.stfName("item_n","corsec_id_badge")		
	return result