from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/player/construction/shared_construction_player_house_generic_small_style_01.iff"
	result.attribute_template_id = -1
	result.stfName("player_structure","temporary_structure")		
	return result