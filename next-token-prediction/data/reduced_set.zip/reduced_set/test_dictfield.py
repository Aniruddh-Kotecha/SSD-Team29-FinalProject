from . import test_settings
from datetime import date
from rest_framework.serializers import ValidationError
from rest_framework import ISO_8601
from rest_framework.serializers import CharField
from rest_framework.serializers import DateField
import pytest
from drf_compound_fields.fields import DictField
def test_to_internal_value_with_child():
    field = DictField(child=DateField())
    data = {"a": "2000-01-01", "b": "2000-01-02"}
    obj = field.to_internal_value(data)
    assert {"a": date(2000, 1, 1), "b": date(2000, 1, 2)} == obj
def test_to_representation_with_child():
    field = DictField(child=DateField(format=ISO_8601))
    obj = {"a": date(2000, 1, 1), "b": date(2000, 1, 2)}
    data = field.to_representation(obj)
    assert {"a": "2000-01-01", "b": "2000-01-02"} == data
def test_validate_non_dict():
    field = DictField(child=DateField())
    with pytest.raises(ValidationError):
        field.to_internal_value('notADict')
def test_validate_elements_valid():
    field = DictField(child=CharField(max_length=5))
    try:
        field.to_internal_value({"a": "a", "b": "b", "c": "c"})
    except ValidationError:
        assert False, "ValidationError was raised"
def test_validate_elements_invalid():
    field = DictField(child=CharField(max_length=5))
    with pytest.raises(ValidationError):
        field.to_internal_value({"a": "012345", "b": "012345"})