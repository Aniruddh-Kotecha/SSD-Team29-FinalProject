class Foo:
    mu = 5
    def test(self):
        foo = 5
        baz[1] = 5
        bar.foo = 5
        self.foo = 5
        biz.baz.foo = 5
        baz[2].foo = 5
        foo += 5
        bar.foo += 5