from collections import OrderedDict
class TopologicalSortError(Exception):
    def __init__(self, message):
        self.message = message
    def __str__(self):
        return "{0}({1})".format(self.__class__.__name__, self.message)
def topological_sort(graph):
    incomming = OrderedDict(
        [
            (node, list(edges)) for node, edges in graph.iteritems()
        ]
    )
    nodes = [node for node in incomming.iterkeys()]
    stack = []
    while nodes:
        n = nodes[0]
        remaining = [node for node in reversed(incomming[n]) if node in nodes]
        if remaining:
            if n not in stack:
                stack.append(n)
            else:
                raise TopologicalSortError(
                    "Cyclic dependency"
                    " detected {0}".format(
                        '->'.join(
                            [
                                str(x) for x in (
                                    stack + [n]
                                )
                            ]
                        )
                    )
                )
            for m in remaining:
                nodes.remove(m)
                nodes.insert(0, m)
        else:
            yield nodes.pop(0)