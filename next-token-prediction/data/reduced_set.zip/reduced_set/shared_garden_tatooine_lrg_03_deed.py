from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/deed/city_deed/shared_garden_tatooine_lrg_03_deed.iff"
	result.attribute_template_id = 2
	result.stfName("deed","garden_tatooine_lrg_03_deed")		
	return result