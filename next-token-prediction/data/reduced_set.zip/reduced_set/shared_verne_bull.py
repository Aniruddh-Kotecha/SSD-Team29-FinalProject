from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_verne_bull.iff"
	result.attribute_template_id = 9
	result.stfName("monster_name","verne")		
	return result