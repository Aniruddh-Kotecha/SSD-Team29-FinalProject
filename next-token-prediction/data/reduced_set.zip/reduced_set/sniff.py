import logging
from time import sleep
from sniffer import Sniffer
from flask import Flask, request, jsonify
app = Flask(__name__)
sniffers = {}
level = logging.DEBUG
logger = logging.getLogger('sniffer')
logger.setLevel(level)
FORMAT = '%(asctime)s - %(name)s - %(levelname)s: %(message)s'
logging.basicConfig(format=FORMAT)
console_handler = logging.StreamHandler()
logger.addHandler(console_handler)
@app.route('/start', methods=['POST'])
def start():
    data = request.get_json()
    source_ip = data['source_ip']
    destination_host = data['destination_host']
    interface = data['interface']
    destination_port = data['destination_port']
    if (source_ip, destination_host) in sniffers:
        err = '409 - Sniffer (source_ip: {}, destination_host: {}) already exists.'.format(source_ip, destination_host)
        logger.warning(err)
        return str(err), 409
    params = {'source_ip': source_ip,
              'destination_host': destination_host,
              'interface': interface,
              'destination_port': destination_port}
    try:
        sniffer = Sniffer(params)
    except AssertionError, err:
        logger.warning(err)
        return str(err), 400
    sniffers[(source_ip, destination_host)] = sniffer
    sniffer.start()
    while not sniffer.is_alive():
        sleep(0.01)
    msg = 'Sniffer (source_ip: {}, destination_host: {}) is alive.'.format(source_ip, destination_host)
    logger.debug(msg)
    return msg, 201
@app.route('/read', methods=['GET'])
def read():
    source_ip = request.args.get('source_ip')
    destination_host = request.args.get('destination_host')
    try:
        sniffer = sniffers[(source_ip, destination_host)]
    except KeyError:
        msg = '(get_sniff) 404 Not Found: Sniffer (source_ip : {}, destination_host: {})'.format(source_ip, destination_host)
        logger.warning(msg)
        return msg, 404
    try:
        capture = sniffer.get_capture()
    except AssertionError, err:
        logger.warning(err)
        return str(err), 422
    assert('capture' in capture)
    logger.debug('Got capture with length: {}'.format(len(capture['capture'])))
    return jsonify(**capture), 200
@app.route('/delete', methods=['POST'])
def delete():
    data = request.get_json()
    source_ip = data['source_ip']
    destination_host = data['destination_host']
    logger.debug('Deleting sniffer (source_ip : {}, destination_host: {})...'.format(source_ip, destination_host))
    try:
        sniffer = sniffers[(source_ip, destination_host)]
    except KeyError:
        msg = '(get_sniff) 404 Not found: Sniffer (source_ip : {}, destination_host: {})'.format(source_ip, destination_host)
        logger.warning(msg)
        return msg, 404
    sniffer.stop()
    sniffer.join()
    del sniffers[(source_ip, destination_host)]
    msg = '(get_sniff) Sniffer (source_ip : {}, destination_host: {}) was deleted.'.format(source_ip, destination_host)
    logger.debug(msg)
    return msg, 200
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=9000, debug=True)