import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), "../test/lib/sqlalchemy/lib"))
from sqlalchemy import Column, ForeignKey, Integer, String, Table, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy import create_engine
metadata = MetaData()
Person = Table('person', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(250), nullable=False)
)
Address = Table('address', metadata,
    Column('id', Integer, primary_key=True),
    Column('street_name', String(250)),
    Column('street_number', String(250)),
    Column('post_code', String(250), nullable=False),
    Column('person_id', Integer, ForeignKey('person.id'))
)
engine = create_engine('sqlite://')
metadata.create_all(engine) 
metadata.bind = engine
DBSession = sessionmaker(bind=engine)
session = DBSession()
for i in xrange(100):
    new_person = Person.insert()
    new_person.execute(name="new person %d" % (i,) )
    new_address = Address.insert()
    new_address.execute(post_code='00000')
    for i in xrange(100):
        s = Person.select()
        rs = s.execute()
print "done"