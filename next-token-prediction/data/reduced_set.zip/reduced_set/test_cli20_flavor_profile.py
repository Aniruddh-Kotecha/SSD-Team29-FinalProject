import sys
from neutronclient.neutron.v2_0.flavor import flavor_profile
from neutronclient.tests.unit import test_cli20
class CLITestV20FlavorProfileJSON(test_cli20.CLITestV20Base):
    def setUp(self):
        super(CLITestV20FlavorProfileJSON, self).setUp(
            plurals={'service_profiles': 'service_profile'})
        self.register_non_admin_status_resource('service_profile')
    def test_create_flavor_profile_with_mandatory_params(self):
        resource = 'service_profile'
        cmd = flavor_profile.CreateFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        name = ''
        description = 'Test flavor profile'
        myid = 'myid'
        metainfo = "{'a':'b'}"
        position_names = ['description', 'metainfo']
        position_values = [description, metainfo]
        args = ['--description', description, '--metainfo', metainfo]
        self._test_create_resource(resource, cmd, name, myid, args,
                                   position_names, position_values)
    def test_create_flavor_profile_with_optional_params(self):
        resource = 'service_profile'
        cmd = flavor_profile.CreateFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        name = ''
        description = 'Test flavor profile - disabled'
        myid = 'myid'
        driver = 'mydriver'
        metainfo = "{'a':'b'}"
        position_names = ['description', 'driver', 'metainfo', 'enabled']
        position_values = [description, driver, metainfo, 'False']
        args = ['--description', description, '--driver', driver,
                '--metainfo', metainfo, '--enabled=False']
        self._test_create_resource(resource, cmd, name, myid, args,
                                   position_names, position_values)
    def test_list_flavor_profiles(self):
        resources = 'service_profiles'
        cmd = flavor_profile.ListFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        self._test_list_resources(resources, cmd, True)
    def test_list_flavor_profiles_with_pagination(self):
        resources = 'service_profiles'
        cmd = flavor_profile.ListFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        self._test_list_resources_with_pagination(resources, cmd)
    def test_list_flavor_profiles_with_sort(self):
        resources = 'service_profiles'
        cmd = flavor_profile.ListFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        self._test_list_resources(resources, cmd,
                                  sort_key=["description"],
                                  sort_dir=["asc"])
    def test_show_flavor_profile(self):
        resource = 'service_profile'
        cmd = flavor_profile.ShowFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        args = ['--fields', 'id', self.test_id]
        self._test_show_resource(resource, cmd, self.test_id, args, ['id'])
    def test_update_flavor_profile(self):
        resource = 'service_profile'
        cmd = flavor_profile.UpdateFlavorProfile(
            test_cli20.MyApp(sys.stdout), None)
        newdescription = 'Test new description'
        newdriver = 'NewDriver'
        newmetainfo = "{'c':'d'}"
        newenabled = "False"
        args = ['--description', newdescription,
                '--driver', newdriver,
                '--metainfo', newmetainfo,
                '--enabled', newenabled,
                self.test_id]
        self._test_update_resource(resource, cmd, self.test_id, args,
                                   {'description': newdescription,
                                    'driver': newdriver,
                                    'metainfo': newmetainfo,
                                    'enabled': newenabled})
    def test_delete_flavor_profile(self):
        resource = 'service_profile'
        cmd = flavor_profile.DeleteFlavorProfile(test_cli20.MyApp(sys.stdout),
                                                 None)
        my_id = 'my-id'
        args = [my_id]
        self._test_delete_resource(resource, cmd, my_id, args)