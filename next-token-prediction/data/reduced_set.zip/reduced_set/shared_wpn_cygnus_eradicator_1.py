from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/weapon/shared_wpn_cygnus_eradicator_1.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","wpn_cygnus_eradicator_1_n")		
	return result