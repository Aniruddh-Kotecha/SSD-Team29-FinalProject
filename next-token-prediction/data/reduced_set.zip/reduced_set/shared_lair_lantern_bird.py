from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/lantern_bird/shared_lair_lantern_bird.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","lantern_bird")		
	return result