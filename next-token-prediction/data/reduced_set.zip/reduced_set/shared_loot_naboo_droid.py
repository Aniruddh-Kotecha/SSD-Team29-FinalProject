from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/space/story_loot/shared_loot_naboo_droid.iff"
	result.attribute_template_id = -1
	result.stfName("space/story_loot_n","loot_naboo_droid")		
	return result