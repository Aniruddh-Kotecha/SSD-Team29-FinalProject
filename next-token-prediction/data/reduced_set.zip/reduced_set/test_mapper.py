import unittest
from zohmg.mapper import Mapper
def m(key, value):
    pass
def mock_mapper(k, v):
    ymd = '20090618'
    yield (ymd, {'agent':'firefox', 'path':'/about'}, {'hit':1})
class TestMapper(unittest.TestCase):
    def test_dict_permutations(self):
        mapper = Mapper(m, [])
        p = mapper.dict_permutations({'agent': 'firefox'})
        self.assertEqual(p, [{'agent': 'firefox'}, {'agent': 'all'}])
        p = mapper.dict_permutations({'a':'x', 'b':'y'})
        expected = [{'a':'x', 'b':'y'}, {'a':'x', 'b':'all'}, {'a':'all', 'b':'y'}, {'a':'all', 'b':'all'}]
        self.assertEqual(p, expected)
        p = mapper.dict_permutations({'agent' : 'firefox', 'country' : 'SE', 'http-status' : '200', 'path':'/'})
        expected = [{'http-status': '200', 'path': '/', 'agent': 'firefox', 'country': 'SE'}, {'http-status': '200', 'path': '/', 'agent': 'all', 'country': 'SE'}, {'http-status': '200', 'path': 'all', 'agent': 'firefox', 'country': 'SE'}, {'http-status': '200', 'path': 'all', 'agent': 'all', 'country': 'SE'}, {'http-status': '200', 'path': '/', 'agent': 'firefox', 'country': 'all'}, {'http-status': '200', 'path': '/', 'agent': 'all', 'country': 'all'}, {'http-status': '200', 'path': 'all', 'agent': 'firefox', 'country': 'all'}, {'http-status': '200', 'path': 'all', 'agent': 'all', 'country': 'all'}, {'http-status': 'all', 'path': '/', 'agent': 'firefox', 'country': 'SE'}, {'http-status': 'all', 'path': '/', 'agent': 'all', 'country': 'SE'}, {'http-status': 'all', 'path': 'all', 'agent': 'firefox', 'country': 'SE'}, {'http-status': 'all', 'path': 'all', 'agent': 'all', 'country': 'SE'}, {'http-status': 'all', 'path': '/', 'agent': 'firefox', 'country': 'all'}, {'http-status': 'all', 'path': '/', 'agent': 'all', 'country': 'all'}, {'http-status': 'all', 'path': 'all', 'agent': 'firefox', 'country': 'all'}, {'http-status': 'all', 'path': 'all', 'agent': 'all', 'country': 'all'}]
        self.assertEqual(p, expected)
    def test_mapper(self):
        mapper = Mapper(mock_mapper, [['agent']])
        output = list(mapper(0, 'bogus value'))
        expected  = []
        expected += [(('20090618', ['agent'], {'agent': 'firefox'}, 'hit'), 1)]
        expected += [(('20090618', ['agent'], {'agent': 'all'}, 'hit'), 1)]
        self.assertEqual(output, expected)
        mapper = Mapper(mock_mapper, [['agent','path'], ['path'], ['agent']])
        output = list(mapper(0, 'bogus value'))
        expected  = []
        expected += [(('20090618', ['agent', 'path'], {'path': '/about', 'agent': 'firefox'}, 'hit'), 1)]
        expected += [(('20090618', ['agent', 'path'], {'path': '/about', 'agent': 'all'}, 'hit'), 1)]
        expected += [(('20090618', ['agent', 'path'], {'path': 'all', 'agent': 'firefox'}, 'hit'), 1)]
        expected += [(('20090618', ['agent', 'path'], {'path': 'all', 'agent': 'all'}, 'hit'), 1)]
        expected += [(('20090618', ['path'], {'path': '/about'}, 'hit'), 1)]
        expected += [(('20090618', ['path'], {'path': 'all'}, 'hit'), 1)]
        expected += [(('20090618', ['agent'], {'agent': 'firefox'}, 'hit'), 1)]
        expected += [(('20090618', ['agent'], {'agent': 'all'}, 'hit'), 1)]
        self.assertEqual(output, expected)
if __name__ == "__main__":
    unittest.main()