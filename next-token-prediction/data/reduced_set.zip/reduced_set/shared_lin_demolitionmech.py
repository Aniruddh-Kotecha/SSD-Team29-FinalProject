from swgpy.object import *	
def create(kernel):
	result = Intangible()
	result.template = "object/intangible/pet/shared_lin_demolitionmech.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result