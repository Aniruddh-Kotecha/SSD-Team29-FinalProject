import os
from textwrap import dedent
import pytest
from django.core import management
from django.core.management import CommandError
from django.test import TestCase
from puente.commands import merge_command
class TestManageMerge(TestCase):
    def test_help(self):
        try:
            management.call_command('merge', '--help')
        except SystemExit:
            pass
def build_filesystem(basedir, files):
    for path, contents in files.items():
        path = os.path.abspath(os.path.join(basedir, path))
        dirname = os.path.dirname(path)
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        with open(path, 'w') as fp:
            fp.write(contents)
class TestMergecommand:
    def test_basic(self, tmpdir):
        locale_dir = tmpdir.join('locale')
        build_filesystem(str(locale_dir), {
            'templates/LC_MESSAGES/django.pot': dedent(),
        })
        merge_command(
            create=True,
            backup=True,
            base_dir=str(tmpdir),
            domain_methods={
                'django': [
                    ('*.py', 'python'),
                    ('*.html', 'jinja2'),
                ]
            },
            languages=['de', 'en-US', 'fr']
        )
        assert locale_dir.join('de', 'LC_MESSAGES', 'django.po').exists()
        assert locale_dir.join('en_US', 'LC_MESSAGES', 'django.po').exists()
        assert locale_dir.join('fr', 'LC_MESSAGES', 'django.po').exists()
    def test_missing_pot_file(self, tmpdir):
        with pytest.raises(CommandError):
            merge_command(
                create=True,
                backup=True,
                base_dir=str(tmpdir),
                domain_methods={
                    'django': [
                        ('*.py', 'python'),
                        ('*.html', 'jinja2'),
                    ]
                },
                languages=['de', 'en-US', 'fr']
            )