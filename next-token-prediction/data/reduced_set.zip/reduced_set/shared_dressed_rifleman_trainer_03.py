from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_rifleman_trainer_03.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","nikto_base_male")		
	return result