from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_corsair_pirate_elite_rod_m.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","rodian_base_male")		
	return result