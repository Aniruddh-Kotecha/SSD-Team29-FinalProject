from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/flora/shared_flora_tree_rori_windswept_s03.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result