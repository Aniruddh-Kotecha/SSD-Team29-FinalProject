from swgpy.object import *	
def create(kernel):
	result = Intangible()
	result.template = "object/draft_schematic/clothing/shared_clothing_wke_shirt_s03.iff"
	result.attribute_template_id = -1
	result.stfName("string_id_table","")		
	return result