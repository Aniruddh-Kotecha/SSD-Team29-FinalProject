from swgpy.object import *	
def create(kernel):
	result = Intangible()
	result.template = "object/draft_schematic/weapon/lightsaber/shared_lightsaber_two_hand_gen4.iff"
	result.attribute_template_id = -1
	result.stfName("string_id_table","")		
	return result