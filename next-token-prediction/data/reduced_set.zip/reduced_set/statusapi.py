import cassiopeia.dto.requests
import cassiopeia.type.dto.status
def get_shards():
    request = "http://status.leagueoflegends.com/shards"
    return [cassiopeia.type.dto.status.Shard(shard) for shard in cassiopeia.dto.requests.get(request, static=True, include_base=False)]
def get_shard():
    request = "http://status.leagueoflegends.com/shards/{region}".format(region=cassiopeia.dto.requests.region)
    return cassiopeia.type.dto.status.ShardStatus(cassiopeia.dto.requests.get(request, static=True, include_base=False))