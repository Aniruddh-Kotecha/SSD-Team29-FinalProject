from gevent._compat import PY2
from gevent._util import copy_globals
def wrap_socket(sock, **kwargs):
    raise NotImplementedError()
if PY2:
    if hasattr(__import__('ssl'), 'SSLContext'):
        from gevent import _sslgte279 as _source
    else:
        from gevent import _ssl2 as _source
else:
    from gevent import _ssl3 as _source
copy_globals(_source, globals())