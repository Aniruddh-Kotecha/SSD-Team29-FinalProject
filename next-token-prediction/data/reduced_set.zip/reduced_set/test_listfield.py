from . import test_settings
from datetime import date
from rest_framework.serializers import ValidationError
from rest_framework import ISO_8601
from rest_framework.serializers import CharField
from rest_framework.serializers import DateField
import pytest
from drf_compound_fields.fields import ListField
def test_to_internal_value_with_item_field():
    field = ListField(child=DateField())
    data = ["2000-01-01", "2000-01-02"]
    obj = field.to_internal_value(data)
    assert [date(2000, 1, 1), date(2000, 1, 2)] == obj
def test_to_representation_with_item_field():
    field = ListField(child=DateField(format=ISO_8601))
    obj = [date(2000, 1, 1), date(2000, 1, 2)]
    data = field.to_representation(obj)
    assert ["2000-01-01", "2000-01-02"] == data
def test_missing_required_list():
    field = ListField(child=DateField())
    with pytest.raises(ValidationError):
        field.to_internal_value(None)
def test_validate_non_list():
    field = ListField(child=DateField())
    with pytest.raises(ValidationError):
        field.to_internal_value('notAList')
def test_errors_non_list():
    field = ListField(child=DateField())
    try:
        field.to_internal_value('notAList')
        assert False, 'Expected ValidationError'
    except ValidationError as e:
        pass
def test_validate_elements_valid():
    field = ListField(child=CharField(max_length=5))
    try:
        field.to_internal_value(["a", "b", "c"])
    except ValidationError:
        assert False, "ValidationError was raised"
def test_validate_elements_invalid():
    field = ListField(child=CharField(max_length=5))
    with pytest.raises(ValidationError):
        field.to_internal_value(["012345", "012345"])