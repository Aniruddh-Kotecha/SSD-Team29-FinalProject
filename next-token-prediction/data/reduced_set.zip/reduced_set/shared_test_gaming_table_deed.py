from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/deed/event_perk/shared_test_gaming_table_deed.iff"
	result.attribute_template_id = 2
	result.stfName("event_perk","test_gaming_table_deed_name")		
	return result