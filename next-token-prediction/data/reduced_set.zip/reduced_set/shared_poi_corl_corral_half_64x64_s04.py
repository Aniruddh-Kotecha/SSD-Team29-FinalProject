from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/structure/general/shared_poi_corl_corral_half_64x64_s04.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result