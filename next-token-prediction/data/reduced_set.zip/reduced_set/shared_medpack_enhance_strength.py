from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/medicine/shared_medpack_enhance_strength.iff"
	result.attribute_template_id = 7
	result.stfName("medicine_name","medpack_enhance_strength")		
	return result