import os
import unittest
import doctest
import StringIO
import ngsutils.fastq
import ngsutils.fastq.fromfasta
class FASTQTest(unittest.TestCase):
    def testSimpleFile(self):
                fastq = ngsutils.fastq.FASTQ(os.path.join(os.path.dirname(__file__), 'test.fastq'))
                names = [x.name.split()[0] for x in fastq.fetch(quiet=True)]
                self.assertEqual(names, ['foo', 'foo', 'bar', 'bar', 'baz', 'baz'])
    def testSimple(self):
        fq = StringIO.StringIO()
        fastq = ngsutils.fastq.FASTQ(fileobj=fq)
        self.assertEqual(fastq.is_paired, False)
        self.assertEqual(fastq.is_colorspace, False)
    def testPaired(self):
        fq = StringIO.StringIO()
        fastq = ngsutils.fastq.FASTQ(fileobj=fq)
        self.assertEqual(fastq.is_paired, True)
        self.assertEqual(fastq.is_colorspace, False)
    def testColorspace(self):
        fq = StringIO.StringIO()
        fastq = ngsutils.fastq.FASTQ(fileobj=fq)
        self.assertEqual(fastq.is_paired, False)
        self.assertEqual(fastq.is_colorspace, True)
def load_tests(loader, tests, ignore):
    tests.addTests(doctest.DocTestSuite(ngsutils.fastq))
    tests.addTests(doctest.DocTestSuite(ngsutils.fastq.fromfasta))
    return tests
if __name__ == '__main__':
    unittest.main()