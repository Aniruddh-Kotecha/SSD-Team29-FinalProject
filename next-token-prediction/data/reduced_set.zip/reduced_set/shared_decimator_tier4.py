from swgpy.object import *	
def create(kernel):
	result = Ship()
	result.template = "object/ship/shared_decimator_tier4.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result