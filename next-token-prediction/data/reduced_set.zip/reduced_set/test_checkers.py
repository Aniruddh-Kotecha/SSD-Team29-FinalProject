from datetime import datetime
import time
import unittest
from babel import __version__ as VERSION
from babel.core import Locale, UnknownLocaleError
from babel.dates import format_datetime
from babel.messages import checkers
from babel.messages.plurals import PLURALS
from babel.messages.pofile import read_po
from babel.util import LOCALTZ
from babel._compat import BytesIO
class CheckersTestCase(unittest.TestCase):
    def test_1_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 1]:
            try:
                locale = Locale.parse(_locale)
            except UnknownLocaleError:
                continue
            po_file = (u % dict(locale=_locale,
                english_name=locale.english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=format_datetime(datetime.now(LOCALTZ),
                                     'yyyy-MM-dd HH:mmZ',
                                     tzinfo=LOCALTZ, locale=_locale),
                num_plurals=PLURALS[_locale][0],
                plural_expr=PLURALS[_locale][0])).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)
    def test_2_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 2]:
            if _locale in ['nn', 'no']:
                _locale = 'nn_NO'
                num_plurals = PLURALS[_locale.split('_')[0]][0]
                plural_expr = PLURALS[_locale.split('_')[0]][1]
            else:
                num_plurals = PLURALS[_locale][0]
                plural_expr = PLURALS[_locale][1]
            try:
                locale = Locale(_locale)
                date = format_datetime(datetime.now(LOCALTZ),
                                       'yyyy-MM-dd HH:mmZ',
                                       tzinfo=LOCALTZ, locale=_locale)
            except UnknownLocaleError:
                continue
            po_file = (u % dict(locale=_locale,
                english_name=locale.english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=date,
                num_plurals=num_plurals,
                plural_expr=plural_expr)).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)
    def test_3_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 3]:
            po_file = (r % dict(locale=_locale,
                english_name=Locale.parse(_locale).english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=format_datetime(datetime.now(LOCALTZ),
                                     'yyyy-MM-dd HH:mmZ',
                                     tzinfo=LOCALTZ, locale=_locale),
                num_plurals=PLURALS[_locale][0],
                plural_expr=PLURALS[_locale][0])).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)
    def test_4_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 4]:
            po_file = (r % dict(locale=_locale,
                english_name=Locale.parse(_locale).english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=format_datetime(datetime.now(LOCALTZ),
                                     'yyyy-MM-dd HH:mmZ',
                                     tzinfo=LOCALTZ, locale=_locale),
                num_plurals=PLURALS[_locale][0],
                plural_expr=PLURALS[_locale][0])).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)
    def test_5_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 5]:
            po_file = (r % dict(locale=_locale,
                english_name=Locale.parse(_locale).english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=format_datetime(datetime.now(LOCALTZ),
                                     'yyyy-MM-dd HH:mmZ',
                                     tzinfo=LOCALTZ, locale=_locale),
                num_plurals=PLURALS[_locale][0],
                plural_expr=PLURALS[_locale][0])).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)
    def test_6_num_plurals_checkers(self):
        for _locale in [p for p in PLURALS if PLURALS[p][0] == 6]:
            po_file = (r % dict(locale=_locale,
                english_name=Locale.parse(_locale).english_name,
                version=VERSION,
                year=time.strftime('%Y'),
                date=format_datetime(datetime.now(LOCALTZ),
                                     'yyyy-MM-dd HH:mmZ',
                                     tzinfo=LOCALTZ, locale=_locale),
                num_plurals=PLURALS[_locale][0],
                plural_expr=PLURALS[_locale][0])).encode('utf-8')
            catalog = read_po(BytesIO(po_file), _locale)
            message = catalog['foobar']
            checkers.num_plurals(catalog, message)