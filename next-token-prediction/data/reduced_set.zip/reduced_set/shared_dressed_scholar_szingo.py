from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_scholar_szingo.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","marauder_base_male")		
	return result