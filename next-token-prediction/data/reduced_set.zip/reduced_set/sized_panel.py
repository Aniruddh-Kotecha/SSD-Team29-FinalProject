import wx
class SizedPanel(wx.Panel):
    def __init__(self, parent, wxid, sizer, **kw):
        wx.Panel.__init__(self, parent, wxid, **kw)
        self.SetSizer(sizer)
        self.SetAutoLayout(True)
        self.sizer = sizer
        return
    def Fit(self):
        self.sizer.Fit(self)
        return
    def Layout(self):
        self.sizer.Layout()
        return