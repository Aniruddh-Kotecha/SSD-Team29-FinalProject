from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/crafted/weapon/missile/shared_wpn_launcher_spacebomb_mk1.iff"
	result.attribute_template_id = 8
	result.stfName("space_crafting_n","wpn_launcher_spacebomb_mk1")		
	return result