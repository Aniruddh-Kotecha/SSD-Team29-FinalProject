from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/crafted/weapon/shared_wpn_experimental_blaster.iff"
	result.attribute_template_id = 8
	result.stfName("space_crafting_n","wpn_experimental_blaster")		
	return result