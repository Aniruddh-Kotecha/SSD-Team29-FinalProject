from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_rebel_specforce_captain_human_female_01.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","human_base_female")		
	return result