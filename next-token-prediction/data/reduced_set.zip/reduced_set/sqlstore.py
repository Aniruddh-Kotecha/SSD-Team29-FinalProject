import re
import time
from openid.association import Association
from openid.store.interface import OpenIDStore
from openid.store import nonce
def _inTxn(func):
    def wrapped(self, *args, **kwargs):
        return self._callInTransaction(func, self, *args, **kwargs)
    if hasattr(func, '__name__'):
        try:
            wrapped.__name__ = func.__name__[4:]
        except TypeError:
            pass
    if hasattr(func, '__doc__'):
        wrapped.__doc__ = func.__doc__
    return wrapped
class SQLStore(OpenIDStore):
    settings_table = 'oid_settings'
    associations_table = 'oid_associations'
    nonces_table = 'oid_nonces'
    def __init__(self, conn, settings_table=None, associations_table=None,
                 nonces_table=None):
        self.conn = conn
        self.cur = None
        self._statement_cache = {}
        self._table_names = {
            'settings': settings_table or self.settings_table,
            'associations': associations_table or self.associations_table,
            'nonces': nonces_table or self.nonces_table,
            }
        self.max_nonce_age = 6 * 60 * 60
        if (hasattr(self.conn, 'IntegrityError') and
            hasattr(self.conn, 'OperationalError')):
            self.exceptions = self.conn
        if not (hasattr(self.exceptions, 'IntegrityError') and
                hasattr(self.exceptions, 'OperationalError')):
            raise RuntimeError("Error using database connection module "
                               "(Maybe it can't be imported?)")
    def blobDecode(self, blob):
        return blob
    def blobEncode(self, s):
        return s
    def _getSQL(self, sql_name):
        try:
            return self._statement_cache[sql_name]
        except KeyError:
            sql = getattr(self, sql_name)
            sql %= self._table_names
            self._statement_cache[sql_name] = sql
            return sql
    def _execSQL(self, sql_name, *args):
        sql = self._getSQL(sql_name)
        self.cur.execute(sql, args)
    def __getattr__(self, attr):
        if attr[:3] == 'db_':
            sql_name = attr[3:] + '_sql'
            def func(*args):
                return self._execSQL(sql_name, *args)
            setattr(self, attr, func)
            return func
        else:
            raise AttributeError('Attribute %r not found' % (attr,))
    def _callInTransaction(self, func, *args, **kwargs):
        self.conn.rollback()
        try:
            self.cur = self.conn.cursor()
            try:
                ret = func(*args, **kwargs)
            finally:
                self.cur.close()
                self.cur = None
        except:
            self.conn.rollback()
            raise
        else:
            self.conn.commit()
        return ret
    def txn_createTables(self):
        self.db_create_nonce()
        self.db_create_assoc()
        self.db_create_settings()
    createTables = _inTxn(txn_createTables)
    def txn_storeAssociation(self, server_url, association):
        a = association
        self.db_set_assoc(
            server_url,
            a.handle,
            self.blobEncode(a.secret),
            a.issued,
            a.lifetime,
            a.assoc_type)
    storeAssociation = _inTxn(txn_storeAssociation)
    def txn_getAssociation(self, server_url, handle=None):
        if handle is not None:
            self.db_get_assoc(server_url, handle)
        else:
            self.db_get_assocs(server_url)
        rows = self.cur.fetchall()
        if len(rows) == 0:
            return None
        else:
            associations = []
            for values in rows:
                assoc = Association(*values)
                assoc.secret = self.blobDecode(assoc.secret)
                if assoc.getExpiresIn() == 0:
                    self.txn_removeAssociation(server_url, assoc.handle)
                else:
                    associations.append((assoc.issued, assoc))
            if associations:
                associations.sort()
                return associations[-1][1]
            else:
                return None
    getAssociation = _inTxn(txn_getAssociation)
    def txn_removeAssociation(self, server_url, handle):
        self.db_remove_assoc(server_url, handle)
        return self.cur.rowcount > 0
    removeAssociation = _inTxn(txn_removeAssociation)
    def txn_useNonce(self, server_url, timestamp, salt):
        if abs(timestamp - time.time()) > nonce.SKEW:
            return False
        try:
            self.db_add_nonce(server_url, timestamp, salt)
        except self.exceptions.IntegrityError:
            return False
        else:
            return True
    useNonce = _inTxn(txn_useNonce)
    def txn_cleanupNonces(self):
        self.db_clean_nonce(int(time.time()) - nonce.SKEW)
        return self.cur.rowcount
    cleanupNonces = _inTxn(txn_cleanupNonces)
    def txn_cleanupAssociations(self):
        self.db_clean_assoc(int(time.time()))
        return self.cur.rowcount
    cleanupAssociations = _inTxn(txn_cleanupAssociations)
class SQLiteStore(SQLStore):
    create_nonce_sql = 
    create_assoc_sql = 
    create_settings_sql = 
    set_assoc_sql = ('INSERT OR REPLACE INTO %(associations)s '
                     'VALUES (?, ?, ?, ?, ?, ?);')
    get_assocs_sql = ('SELECT handle, secret, issued, lifetime, assoc_type '
                      'FROM %(associations)s WHERE server_url = ?;')
    get_assoc_sql = (
        'SELECT handle, secret, issued, lifetime, assoc_type '
        'FROM %(associations)s WHERE server_url = ? AND handle = ?;')
    get_expired_sql = ('SELECT server_url '
                       'FROM %(associations)s WHERE issued + lifetime < ?;')
    remove_assoc_sql = ('DELETE FROM %(associations)s '
                        'WHERE server_url = ? AND handle = ?;')
    clean_assoc_sql = 'DELETE FROM %(associations)s WHERE issued + lifetime < ?;'
    add_nonce_sql = 'INSERT INTO %(nonces)s VALUES (?, ?, ?);'
    clean_nonce_sql = 'DELETE FROM %(nonces)s WHERE timestamp < ?;'
    def blobDecode(self, buf):
        return str(buf)
    def blobEncode(self, s):
        return buffer(s)
    def useNonce(self, *args, **kwargs):
        try:
            return super(SQLiteStore, self).useNonce(*args, **kwargs)
        except self.exceptions.OperationalError, why:
            if re.match('^columns .* are not unique$', why[0]):
                return False
            else:
                raise
class MySQLStore(SQLStore):
    try:
        import MySQLdb as exceptions
    except ImportError:
        exceptions = None
    create_nonce_sql = 
    create_assoc_sql = 
    create_settings_sql = 
    set_assoc_sql = ('REPLACE INTO %(associations)s '
                     'VALUES (%%s, %%s, %%s, %%s, %%s, %%s);')
    get_assocs_sql = ('SELECT handle, secret, issued, lifetime, assoc_type'
                      ' FROM %(associations)s WHERE server_url = %%s;')
    get_expired_sql = ('SELECT server_url '
                       'FROM %(associations)s WHERE issued + lifetime < %%s;')
    get_assoc_sql = (
        'SELECT handle, secret, issued, lifetime, assoc_type'
        ' FROM %(associations)s WHERE server_url = %%s AND handle = %%s;')
    remove_assoc_sql = ('DELETE FROM %(associations)s '
                        'WHERE server_url = %%s AND handle = %%s;')
    clean_assoc_sql = 'DELETE FROM %(associations)s WHERE issued + lifetime < %%s;'
    add_nonce_sql = 'INSERT INTO %(nonces)s VALUES (%%s, %%s, %%s);'
    clean_nonce_sql = 'DELETE FROM %(nonces)s WHERE timestamp < %%s;'
    def blobDecode(self, blob):
        if type(blob) is str:
            return blob
        else:
            return blob.tostring()
class PostgreSQLStore(SQLStore):
    try:
        import psycopg as exceptions
    except ImportError:
        exceptions = None
    create_nonce_sql = 
    create_assoc_sql = 
    create_settings_sql = 
    def db_set_assoc(self, server_url, handle, secret, issued, lifetime, assoc_type):
        result = self.db_get_assoc(server_url, handle)
        rows = self.cur.fetchall()
        if len(rows):
            return self.db_update_assoc(secret, issued, lifetime, assoc_type,
                                        server_url, handle)
        else:
            return self.db_new_assoc(server_url, handle, secret, issued,
                                     lifetime, assoc_type)
    new_assoc_sql = ('INSERT INTO %(associations)s '
                     'VALUES (%%s, %%s, %%s, %%s, %%s, %%s);')
    update_assoc_sql = ('UPDATE %(associations)s SET '
                        'secret = %%s, issued = %%s, '
                        'lifetime = %%s, assoc_type = %%s '
                        'WHERE server_url = %%s AND handle = %%s;')
    get_assocs_sql = ('SELECT handle, secret, issued, lifetime, assoc_type'
                      ' FROM %(associations)s WHERE server_url = %%s;')
    get_expired_sql = ('SELECT server_url '
                       'FROM %(associations)s WHERE issued + lifetime < %%s;')
    get_assoc_sql = (
        'SELECT handle, secret, issued, lifetime, assoc_type'
        ' FROM %(associations)s WHERE server_url = %%s AND handle = %%s;')
    remove_assoc_sql = ('DELETE FROM %(associations)s '
                        'WHERE server_url = %%s AND handle = %%s;')
    clean_assoc_sql = 'DELETE FROM %(associations)s WHERE issued + lifetime < %%s;'
    add_nonce_sql = 'INSERT INTO %(nonces)s VALUES (%%s, %%s, %%s);'
    clean_nonce_sql = 'DELETE FROM %(nonces)s WHERE timestamp < %%s;'
    def blobEncode(self, blob):
        try:
            from psycopg2 import Binary
        except ImportError:
            from psycopg import Binary
        return Binary(blob)