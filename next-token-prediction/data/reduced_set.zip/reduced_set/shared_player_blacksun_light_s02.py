from swgpy.object import *	
def create(kernel):
	result = Ship()
	result.template = "object/ship/player/shared_player_blacksun_light_s02.iff"
	result.attribute_template_id = -1
	result.stfName("space_ship","player_blacksun_light_s02")		
	return result