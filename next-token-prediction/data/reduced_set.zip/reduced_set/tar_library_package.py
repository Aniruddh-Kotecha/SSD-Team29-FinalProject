__author__ = 'sammccall@google.com (Sam McCall)'
from io import BytesIO
import StringIO
import tarfile
import time
from googleapis.codegen.filesys.library_package import LibraryPackage
class TarLibraryPackage(LibraryPackage):
  def __init__(self, stream, compress=True):
    super(TarLibraryPackage, self).__init__()
    mode = 'w:gz' if compress else 'w'
    self._tar = tarfile.open(fileobj=stream, mode=mode)
    self._current_file_data = None
    self._compress = compress
  def StartFile(self, name):
    self.EndFile()
    self._current_file_data = StringIO.StringIO()
    name = '%s%s' % (self._file_path_prefix, name)
    self._current_file_name = name.encode('ascii')
    return self._current_file_data
  def EndFile(self):
    if self._current_file_data:
      info = tarfile.TarInfo(self._current_file_name)
      info.mtime = time.time()
      info.mode = 0644
      data = self._current_file_data.getvalue()
      if isinstance(data, unicode):
        data = data.encode('utf-8')
      info.size = len(data)
      self._tar.addfile(info, BytesIO(data))
      self._current_file_data.close()
      self._current_file_data = None
  def DoneWritingArchive(self):
    if self._tar:
      self.EndFile()
      self._tar.close()
      self._tar = None
  def FileExtension(self):
    if self._compress:
      return 'tgz'
    else:
      return 'tar'
  def MimeType(self):
    if self._compress:
      return 'application/x-gtar-compressed'
    return 'application/x-gtar'