from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/poi/shared_corellia_afarathu_large1.iff"
	result.attribute_template_id = -1
	result.stfName("poi_n","base_poi_building")		
	return result