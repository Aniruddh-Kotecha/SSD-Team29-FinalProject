from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/installation/shared_mockup_mining_liquid_moisture_harvester.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result