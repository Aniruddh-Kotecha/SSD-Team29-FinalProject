from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/player/city/shared_garden_naboo_med_04.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","garden")		
	return result