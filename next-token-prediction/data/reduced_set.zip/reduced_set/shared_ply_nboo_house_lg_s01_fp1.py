from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/naboo/shared_ply_nboo_house_lg_s01_fp1.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","housing_naboo_style_1")		
	return result