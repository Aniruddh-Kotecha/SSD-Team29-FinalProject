from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/weapon/shared_wpn_reward_incom_elite.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","wpn_reward_incom_elite")		
	return result