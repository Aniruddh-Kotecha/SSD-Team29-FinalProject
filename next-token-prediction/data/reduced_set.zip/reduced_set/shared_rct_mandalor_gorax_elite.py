from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/reactor/shared_rct_mandalor_gorax_elite.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","rct_mandalor_gorax_elite_n")		
	return result