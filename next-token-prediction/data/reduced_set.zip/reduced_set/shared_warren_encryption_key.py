from swgpy.object import *	
def create(kernel):
	result = Intangible()
	result.template = "object/intangible/data_item/shared_warren_encryption_key.iff"
	result.attribute_template_id = -1
	result.stfName("warren_item_n","warren_encryption_key")		
	return result