import os
try:
    import ogr
except ImportError:
    from osgeo import ogr
line_shp_file = "../static_files/shapefile/rivers_lake_centerlines/ne_50m_rivers_lake_centerlines.shp"
line_datasource = ogr.Open(line_shp_file)
driver = ogr.GetDriverByName('ESRI Shapefile')
point_shp_file = 'points.shp'
layer_name = 'point_layer'
if os.path.exists(point_shp_file):
    driver.DeleteDataSource(point_shp_file)
point_datasource = driver.CreateDataSource(point_shp_file)
layer_count = line_datasource.GetLayerCount()
for each_layer in range(layer_count):
    layer = line_datasource.GetLayerByIndex(each_layer)
    srs = layer.GetSpatialRef()
    point_shp_layer = point_datasource.CreateLayer(layer_name, srs, ogr.wkbPoint)
    feature_count = layer.GetFeatureCount()
    for each_feature in range(feature_count):
        line_feature = layer.GetFeature(each_feature)
        feature_geom = line_feature.GetGeometryRef()
        if feature_geom.GetGeometryName() != 'MULTILINESTRING':
            points = feature_geom.GetPoints()
            for point in points:
                point_geom = ogr.Geometry(ogr.wkbPoint)
                point_geom.AddPoint(point[0], point[1])
                point_feature = ogr.Feature(point_shp_layer.GetLayerDefn())
                point_feature.SetGeometry(point_geom)
                point_shp_layer.CreateFeature(point_feature)