from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/deed/pet_deed/shared_kaadu_deed.iff"
	result.attribute_template_id = 2
	result.stfName("pet_deed","kaadu")		
	result.setStringAttribute("radial_filename", "radials/deed_datapad.py")
	result.setStringAttribute("deed_pcd", "object/intangible/pet/shared_kaadu_hue.iff")
	result.setStringAttribute("deed_mobile", "object/mobile/shared_kaadu_hue.iff")
	return result