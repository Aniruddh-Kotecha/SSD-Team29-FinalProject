from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/mission/quest_item/shared_oxil_sarban_q1_needed.iff"
	result.attribute_template_id = -1
	result.stfName("loot_rori_n","oxil_sarban_q1_needed")		
	return result