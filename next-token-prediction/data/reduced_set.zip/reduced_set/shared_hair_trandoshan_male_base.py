from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/hair/trandoshan/base/shared_hair_trandoshan_male_base.iff"
	result.attribute_template_id = -1
	result.stfName("hair_name","ridges")		
	return result