from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/furniture/modern/shared_rug_rnd_lg_s01.iff"
	result.attribute_template_id = 6
	result.stfName("frn_n","frn_rug_rnd_lg_01")		
	return result