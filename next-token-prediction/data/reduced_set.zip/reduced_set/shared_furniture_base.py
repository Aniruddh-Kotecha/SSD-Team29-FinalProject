from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/furniture/base/shared_furniture_base.iff"
	result.attribute_template_id = 6
	result.stfName("item_n","default_furniture")		
	return result