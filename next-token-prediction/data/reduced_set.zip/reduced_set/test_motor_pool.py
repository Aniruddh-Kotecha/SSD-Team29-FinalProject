from __future__ import unicode_literals
import functools
import greenlet
import random
import unittest
import pymongo.errors
from tornado import stack_context, version_info as tornado_version
from tornado.concurrent import Future
from tornado.testing import gen_test
from test import SkipTest
from test.test_environment import host, port
from test.tornado_tests import MotorTest
from test.utils import delay, one
import motor
import motor.core
from motor.frameworks import tornado as tornado_framework
class MotorPoolTest(MotorTest):
    @gen_test
    def test_max_size_default(self):
        yield self.cx.open()
        pool = self.cx._get_primary_pool()
        self.assertEqual(100, pool.max_size)
        self.assertEqual(None, pool.wait_queue_timeout)
        self.assertEqual(None, pool.wait_queue_multiple)
    @gen_test(timeout=30)
    def test_max_size(self):
        max_pool_size = 5
        cx = self.motor_client(max_pool_size=max_pool_size)
        self.assertEqual(None, cx._get_primary_pool())
        yield cx.motor_test.test_collection.remove()
        pool = cx._get_primary_pool()
        self.assertEqual(max_pool_size, pool.max_size)
        self.assertEqual(1, len(pool.sockets))
        self.assertEqual(1, pool.motor_sock_counter)
        ops_completed = Future()
        nops = 100
        results = []
        def callback(i, result, error):
            self.assertFalse(error)
            self.assertFalse(pool.motor_sock_counter > max_pool_size)
            results.append(i)
            if len(results) == nops:
                ops_completed.set_result(None)
        collection = cx.motor_test.test_collection
        yield collection.insert({})
        for i in range(nops):
            collection.find_one(
                {'$where': delay(random.random() / 10)},
                callback=functools.partial(callback, i))
        yield ops_completed
        self.assertEqual(list(range(nops)), sorted(results))
        self.assertNotEqual(list(range(nops)), results)
        self.assertEqual(max_pool_size, len(pool.sockets))
        self.assertEqual(max_pool_size, pool.motor_sock_counter)
        cx.close()
    @gen_test(timeout=30)
    def test_force(self):
        cx = self.motor_client(max_pool_size=2, waitQueueTimeoutMS=100)
        yield cx.open()
        pool = cx._get_primary_pool()
        def get_socket():
            s = pool.get_socket(force=True)
            self.io_loop.add_callback(functools.partial(future.set_result, s))
        future = Future()
        greenlet.greenlet(get_socket).switch()
        socket_info = yield future
        self.assertEqual(1, pool.motor_sock_counter)
        future = Future()
        greenlet.greenlet(get_socket).switch()
        socket_info2 = yield future
        self.assertEqual(2, pool.motor_sock_counter)
        future = Future()
        greenlet.greenlet(get_socket).switch()
        forced_socket_info = yield future
        self.assertEqual(3, pool.motor_sock_counter)
        future = Future()
        greenlet.greenlet(get_socket).switch()
        forced_socket_info2 = yield future
        self.assertEqual(4, pool.motor_sock_counter)
        pool.maybe_return_socket(socket_info)
        self.assertTrue(socket_info.closed)
        self.assertEqual(0, len(pool.sockets))
        self.assertEqual(3, pool.motor_sock_counter)
        pool.maybe_return_socket(socket_info2)
        self.assertTrue(socket_info2.closed)
        self.assertEqual(0, len(pool.sockets))
        self.assertEqual(2, pool.motor_sock_counter)
        forced_socket_info.close()
        pool.maybe_return_socket(forced_socket_info)
        self.assertEqual(0, len(pool.sockets))
        self.assertEqual(1, pool.motor_sock_counter)
        pool.maybe_return_socket(forced_socket_info2)
        self.assertFalse(forced_socket_info2.closed)
        self.assertEqual(1, len(pool.sockets))
        self.assertEqual(1, pool.motor_sock_counter)
        cx.close()
    @gen_test(timeout=30)
    def test_wait_queue_timeout(self):
        if tornado_version < (4, 0, 0, 0):
            raise SkipTest("MOTOR-73")
        where_delay = 1
        yield self.collection.insert({})
        for waitQueueTimeoutMS in (500, 5000, None):
            cx = self.motor_client(
                max_pool_size=1, waitQueueTimeoutMS=waitQueueTimeoutMS)
            yield cx.open()
            pool = cx._get_primary_pool()
            if waitQueueTimeoutMS:
                self.assertEqual(
                    waitQueueTimeoutMS, pool.wait_queue_timeout * 1000)
            else:
                self.assertTrue(pool.wait_queue_timeout is None)
            collection = cx.motor_test.test_collection
            future = collection.find_one({'$where': delay(where_delay)})
            if waitQueueTimeoutMS and waitQueueTimeoutMS < where_delay * 1000:
                with self.assertRaises(pymongo.errors.ConnectionFailure):
                    yield collection.find_one()
            else:
                yield collection.find_one()
            yield future
            cx.close()
    @gen_test(timeout=30)
    def test_wait_queue_multiple(self):
        cx = self.motor_client(max_pool_size=2,
                               waitQueueTimeoutMS=100,
                               waitQueueMultiple=3)
        yield cx.open()
        pool = cx._get_primary_pool()
        def get_socket_on_greenlet(future):
            try:
                s = pool.get_socket()
                future.set_result(s)
            except Exception as e:
                future.set_exception(e)
        def get_socket():
            future = Future()
            fn = functools.partial(get_socket_on_greenlet, future)
            greenlet.greenlet(fn).switch()
            return future
        s1 = yield get_socket()
        self.assertEqual(1, pool.motor_sock_counter)
        s2 = yield get_socket()
        self.assertEqual(2, pool.motor_sock_counter)
        start = self.io_loop.time()
        with self.assertRaises(pymongo.errors.ConnectionFailure):
            yield get_socket()
        self.assertAlmostEqual(0.1, self.io_loop.time() - start, places=1)
        self.assertEqual(2, pool.motor_sock_counter)
        s1_future = get_socket()
        pool.maybe_return_socket(s1)
        self.assertEqual(s1, (yield s1_future))
        self.assertEqual(2, pool.motor_sock_counter)
        for _ in range(6):
            get_socket()
        start = self.io_loop.time()
        with self.assertRaises(pymongo.errors.ConnectionFailure):
            yield get_socket()
        self.assertAlmostEqual(0, self.io_loop.time() - start, places=2)
        self.assertEqual(2, pool.motor_sock_counter)
        cx.close()
    @gen_test
    def test_connections_unacknowledged_writes(self):
        collection = self.cx.motor_test.test_collection
        yield collection.drop()
        pool = self.cx._get_primary_pool()
        self.assertEqual(1, pool.motor_sock_counter)
        nops = 10
        for i in range(nops - 1):
            collection.insert({'_id': i}, w=0)
            self.assertEqual(1, pool.motor_sock_counter)
            self.assertEqual(1, len(pool.sockets))
        yield collection.insert({'_id': nops - 1})
        self.assertEqual(1, pool.motor_sock_counter)
        self.assertEqual(1, len(pool.sockets))
        docs = yield collection.find().sort('_id').to_list(length=100)
        self.assertEqual(list(range(nops)), [doc['_id'] for doc in docs])
    @gen_test
    def test_check_socket(self):
        yield self.cx.open()
        pool = self.cx._get_primary_pool()
        pool._check_interval_seconds = 0
        counter = pool.motor_sock_counter
        sock_info = one(pool.sockets)
        sock_info.sock.close()
        pool.maybe_return_socket(sock_info)
        yield self.cx.server_info()
        sock_info2 = one(pool.sockets)
        self.assertNotEqual(sock_info, sock_info2)
        self.assertEqual(counter, pool.motor_sock_counter)
    @gen_test
    def test_stack_context(self):
        loop = self.io_loop
        history = []
        cx = self.motor_client(max_pool_size=1)
        yield cx.motor_test.test_collection.find_one()
        pool = cx._get_primary_pool()
        self.assertEqual(1, len(pool.sockets))
        sock_info = pool.get_socket()
        main_gr = greenlet.getcurrent()
        def catch_get_sock_exc(exc_type, exc_value, exc_traceback):
            history.extend(['get_sock_exc', exc_value])
            return True
        def catch_return_sock_exc(exc_type, exc_value, exc_traceback):
            history.extend(['return_sock_exc', exc_value])
            return True
        def get_socket():
            pool.get_socket()
            loop.add_callback(raise_callback)
        my_assert = AssertionError('foo')
        def raise_callback():
            history.append('raise')
            raise my_assert
        def return_socket():
            with stack_context.ExceptionStackContext(catch_return_sock_exc):
                pool.maybe_return_socket(sock_info)
            main_gr.switch()
        with stack_context.ExceptionStackContext(catch_get_sock_exc):
            loop.add_callback(greenlet.greenlet(get_socket).switch)
        greenlet.greenlet(return_socket).switch()
        yield self.pause(0.1)
        self.assertEqual(['raise', 'get_sock_exc', my_assert], history)
        cx.close()
    @gen_test
    def test_resolve_stack_context(self):
        future = Future()
        my_assert = AssertionError('foo')
        pool = motor.core.MotorPool(
            io_loop=self.io_loop,
            framework=tornado_framework,
            pair=(host, port),
            max_size=1,
            net_timeout=None,
            conn_timeout=100,
            use_ssl=False,
            use_greenlets=None)
        def get_socket():
            pool.get_socket()
            self.io_loop.add_callback(raise_callback)
        def raise_callback():
            raise my_assert
        def catch_get_sock_exc(exc_type, exc_value, exc_traceback):
            future.set_exception(exc_value)
            return True
        with stack_context.ExceptionStackContext(catch_get_sock_exc):
            self.io_loop.add_callback(greenlet.greenlet(get_socket).switch)
        with self.assertRaises(AssertionError) as context:
            yield future
        self.assertEqual(context.exception, my_assert)
if __name__ == '__main__':
    unittest.main()