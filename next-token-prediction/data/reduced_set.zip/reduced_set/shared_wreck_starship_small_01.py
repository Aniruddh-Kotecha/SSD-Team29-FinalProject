from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/destructible/wreckage/shared_wreck_starship_small_01.iff"
	result.attribute_template_id = -1
	result.stfName("container_name","newbie_tutorial_debris")		
	return result