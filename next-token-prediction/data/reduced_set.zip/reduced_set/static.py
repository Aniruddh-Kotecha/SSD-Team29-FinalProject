from __future__ import absolute_import
from slimta.util import validate_tls
from .client import SmtpRelayClient
from .lmtpclient import LmtpRelayClient
from ..pool import RelayPool
__all__ = ['StaticSmtpRelay', 'StaticLmtpRelay']
class StaticSmtpRelay(RelayPool):
    _default_class = SmtpRelayClient
    def __init__(self, host, port=25, pool_size=None, client_class=None,
                 tls=None, **client_kwargs):
        super(StaticSmtpRelay, self).__init__(pool_size)
        self.client_class = client_class or self._default_class
        self.host = host
        self.port = port
        self.client_kwargs = client_kwargs
        self.client_kwargs['tls'] = validate_tls(tls)
    def add_client(self):
        return self.client_class((self.host, self.port), self.queue,
                                 **self.client_kwargs)
class StaticLmtpRelay(StaticSmtpRelay):
    _default_class = LmtpRelayClient
    def __init__(self, host='localhost', port=24, pool_size=None,
                 **client_kwargs):
        super(StaticLmtpRelay, self).__init__(host, port, pool_size,
                                              **client_kwargs)