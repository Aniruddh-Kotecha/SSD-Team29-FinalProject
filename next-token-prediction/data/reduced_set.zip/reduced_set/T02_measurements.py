from vispy import app, gloo, visuals, scene
import numpy as np
vertex_shader = 
fragment_shader = 
class MyRectVisual(visuals.Visual):
    def __init__(self, x, y, w, h, weight=4.0):
        visuals.Visual.__init__(self, vertex_shader, fragment_shader)
        self.vert_buffer = gloo.VertexBuffer(np.array([
            [x, y], 
            [x, y], 
            [x+w, y], 
            [x+w, y], 
            [x+w, y+h],
            [x+w, y+h],
            [x, y+h],
            [x, y+h],
            [x, y], 
            [x, y], 
        ], dtype=np.float32))
        self.adj_buffer = gloo.VertexBuffer(np.array([
            [0, 0],
            [1, 1],
            [0, 0],
            [-1, 1],
            [0, 0],
            [-1, -1],
            [0, 0],
            [1, -1],
            [0, 0],
            [1, 1],
        ], dtype=np.float32))
        self.shared_program.vert['position'] = self.vert_buffer
        self.shared_program.vert['adjust_dir'] = self.adj_buffer
        self.shared_program.vert['line_width'] = weight
        self.shared_program.frag['color'] = (1, 0, 0, 1)
        self.set_gl_state(cull_face=False)
        self._draw_mode = 'triangle_strip'
    def _prepare_transforms(self, view):
        tr = view.transforms
        view_vert = view.view_program.vert
        view_vert['visual_to_doc'] = tr.get_transform('visual', 'document')
        view_vert['doc_to_render'] = tr.get_transform('document', 'render')
MyRect = scene.visuals.create_visual_node(MyRectVisual)
canvas = scene.SceneCanvas(keys='interactive', show=True)
view = canvas.central_widget.add_view()
view.camera = 'panzoom'
view.camera.rect = (0, 0, 800, 800)
rects = [MyRect(100, 100, 200, 300, parent=view.scene),
         MyRect(500, 100, 200, 300, parent=view.scene)]
tr = visuals.transforms.MatrixTransform()
tr.rotate(25, (0, 0, 1))
rects[1].transform = tr
text = scene.visuals.Text("Drag right mouse button to zoom.", color='w',
                          anchor_x='left', parent=view, pos=(20, 30))
if __name__ == '__main__':
    import sys
    if sys.flags.interactive != 1:
        app.run()