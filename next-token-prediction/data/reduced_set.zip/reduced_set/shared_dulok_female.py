from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dulok_female.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","dulok_base_female")		
	return result