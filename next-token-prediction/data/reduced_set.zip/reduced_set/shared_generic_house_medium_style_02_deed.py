from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/deed/player_house_deed/shared_generic_house_medium_style_02_deed.iff"
	result.attribute_template_id = 2
	result.stfName("deed","generic_house_medium_style_2_deed")		
	return result