import unittest
from examples import connect
from examples.image import create as image_create
from examples.image import delete as image_delete
from examples.image import list as image_list
class TestImage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.conn = connect.create_connection_from_config()
    def test_image(self):
        image_list.list_images(self.conn)
        image_create.upload_image(self.conn)
        image_delete.delete_image(self.conn)