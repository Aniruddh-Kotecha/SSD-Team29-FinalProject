from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/medicine/crafted/shared_medpack_disease_strength_a.iff"
	result.attribute_template_id = 7
	result.stfName("medicine_name","medic_disease_strength_a")		
	return result