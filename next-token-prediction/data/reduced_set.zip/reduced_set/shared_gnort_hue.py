from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_gnort_hue.iff"
	result.attribute_template_id = 9
	result.stfName("monster_name","gnort")		
	result.setStringAttribute("radial_filename", "radials/player_pet.py")
	result.options_mask = 0x100
	result.pvp_status = PVPSTATUS.PvPStatus_None
	return result