from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/space/content_infrastructure/shared_patrol_spawner.iff"
	result.attribute_template_id = -1
	result.stfName("item_n","spawner")		
	return result