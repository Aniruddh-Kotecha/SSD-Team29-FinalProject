from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/structure/dantooine/shared_dant_imprv_bannerpole_s01.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result