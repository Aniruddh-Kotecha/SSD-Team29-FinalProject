from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/medicine/crafted/shared_medpack_enhance_constitution_d.iff"
	result.attribute_template_id = 7
	result.stfName("medicine_name","medpack_enhance_constitution_d")		
	return result