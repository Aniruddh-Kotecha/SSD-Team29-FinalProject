from __future__ import print_function
from __future__ import division
import warnings
import inspect
from itertools import chain, combinations
from collections import Iterable
from math import ceil, floor
import numbers
from abc import ABCMeta, abstractmethod
import numpy as np
from scipy.misc import comb
from ..utils import indexable, check_random_state, safe_indexing
from ..utils.validation import _num_samples, column_or_1d
from ..utils.multiclass import type_of_target
from ..externals.six import with_metaclass
from ..externals.six.moves import zip
from ..utils.fixes import bincount
from ..utils.fixes import signature
from ..base import _pprint
from ..gaussian_process.kernels import Kernel as GPKernel
__all__ = ['BaseCrossValidator',
           'KFold',
           'LabelKFold',
           'LeaveOneLabelOut',
           'LeaveOneOut',
           'LeavePLabelOut',
           'LeavePOut',
           'ShuffleSplit',
           'LabelShuffleSplit',
           'StratifiedKFold',
           'StratifiedShuffleSplit',
           'PredefinedSplit',
           'train_test_split',
           'check_cv']
class BaseCrossValidator(with_metaclass(ABCMeta)):
    def __init__(self):
        pass
    def split(self, X, y=None, labels=None):
        X, y, labels = indexable(X, y, labels)
        indices = np.arange(_num_samples(X))
        for test_index in self._iter_test_masks(X, y, labels):
            train_index = indices[np.logical_not(test_index)]
            test_index = indices[test_index]
            yield train_index, test_index
    def _iter_test_masks(self, X=None, y=None, labels=None):
        for test_index in self._iter_test_indices(X, y, labels):
            test_mask = np.zeros(_num_samples(X), dtype=np.bool)
            test_mask[test_index] = True
            yield test_mask
    def _iter_test_indices(self, X=None, y=None, labels=None):
        raise NotImplementedError
    @abstractmethod
    def get_n_splits(self, X=None, y=None, labels=None):
    def __repr__(self):
        return _build_repr(self)
class LeaveOneOut(BaseCrossValidator):
    def _iter_test_indices(self, X, y=None, labels=None):
        return range(_num_samples(X))
    def get_n_splits(self, X, y=None, labels=None):
        if X is None:
            raise ValueError("The X parameter should not be None")
        return _num_samples(X)
class LeavePOut(BaseCrossValidator):
    def __init__(self, p):
        self.p = p
    def _iter_test_indices(self, X, y=None, labels=None):
        for combination in combinations(range(_num_samples(X)), self.p):
            yield np.array(combination)
    def get_n_splits(self, X, y=None, labels=None):
        if X is None:
            raise ValueError("The X parameter should not be None")
        return int(comb(_num_samples(X), self.p, exact=True))
class _BaseKFold(with_metaclass(ABCMeta, BaseCrossValidator)):
    @abstractmethod
    def __init__(self, n_folds, shuffle, random_state):
        if not isinstance(n_folds, numbers.Integral):
            raise ValueError('The number of folds must be of Integral type. '
                             '%s of type %s was passed.'
                             % (n_folds, type(n_folds)))
        n_folds = int(n_folds)
        if n_folds <= 1:
            raise ValueError(
                "k-fold cross-validation requires at least one"
                " train/test split by setting n_folds=2 or more,"
                " got n_folds={0}.".format(n_folds))
        if not isinstance(shuffle, bool):
            raise TypeError("shuffle must be True or False;"
                            " got {0}".format(shuffle))
        self.n_folds = n_folds
        self.shuffle = shuffle
        self.random_state = random_state
    def split(self, X, y=None, labels=None):
        X, y, labels = indexable(X, y, labels)
        n_samples = _num_samples(X)
        if self.n_folds > n_samples:
            raise ValueError(
                ("Cannot have number of folds n_folds={0} greater"
                 " than the number of samples: {1}.").format(self.n_folds,
                                                             n_samples))
        for train, test in super(_BaseKFold, self).split(X, y, labels):
            yield train, test
    def get_n_splits(self, X=None, y=None, labels=None):
        return self.n_folds
class KFold(_BaseKFold):
    def __init__(self, n_folds=3, shuffle=False,
                 random_state=None):
        super(KFold, self).__init__(n_folds, shuffle, random_state)
    def _iter_test_indices(self, X, y=None, labels=None):
        n_samples = _num_samples(X)
        indices = np.arange(n_samples)
        if self.shuffle:
            check_random_state(self.random_state).shuffle(indices)
        n_folds = self.n_folds
        fold_sizes = (n_samples // n_folds) * np.ones(n_folds, dtype=np.int)
        fold_sizes[:n_samples % n_folds] += 1
        current = 0
        for fold_size in fold_sizes:
            start, stop = current, current + fold_size
            yield indices[start:stop]
            current = stop
class LabelKFold(_BaseKFold):
    def __init__(self, n_folds=3):
        super(LabelKFold, self).__init__(n_folds, shuffle=False,
                                         random_state=None)
    def _iter_test_indices(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        unique_labels, labels = np.unique(labels, return_inverse=True)
        n_labels = len(unique_labels)
        if self.n_folds > n_labels:
            raise ValueError("Cannot have number of folds n_folds=%d greater"
                             " than the number of labels: %d."
                             % (self.n_folds, n_labels))
        n_samples_per_label = np.bincount(labels)
        indices = np.argsort(n_samples_per_label)[::-1]
        n_samples_per_label = n_samples_per_label[indices]
        n_samples_per_fold = np.zeros(self.n_folds)
        label_to_fold = np.zeros(len(unique_labels))
        for label_index, weight in enumerate(n_samples_per_label):
            lightest_fold = np.argmin(n_samples_per_fold)
            n_samples_per_fold[lightest_fold] += weight
            label_to_fold[indices[label_index]] = lightest_fold
        indices = label_to_fold[labels]
        for f in range(self.n_folds):
            yield np.where(indices == f)[0]
class StratifiedKFold(_BaseKFold):
    def __init__(self, n_folds=3, shuffle=False, random_state=None):
        super(StratifiedKFold, self).__init__(n_folds, shuffle, random_state)
    def _make_test_folds(self, X, y=None, labels=None):
        if self.shuffle:
            rng = check_random_state(self.random_state)
        else:
            rng = self.random_state
        y = np.asarray(y)
        n_samples = y.shape[0]
        unique_y, y_inversed = np.unique(y, return_inverse=True)
        y_counts = bincount(y_inversed)
        min_labels = np.min(y_counts)
        if np.all(self.n_folds > y_counts):
            raise ValueError("All the n_labels for individual classes"
                             " are less than %d folds."
                             % (self.n_folds))
        if self.n_folds > min_labels:
            warnings.warn(("The least populated class in y has only %d"
                           " members, which is too few. The minimum"
                           " number of labels for any class cannot"
                           " be less than n_folds=%d."
                           % (min_labels, self.n_folds)), Warning)
        per_cls_cvs = [
            KFold(self.n_folds, shuffle=self.shuffle,
                  random_state=rng).split(np.zeros(max(count, self.n_folds)))
            for count in y_counts]
        test_folds = np.zeros(n_samples, dtype=np.int)
        for test_fold_indices, per_cls_splits in enumerate(zip(*per_cls_cvs)):
            for cls, (_, test_split) in zip(unique_y, per_cls_splits):
                cls_test_folds = test_folds[y == cls]
                test_split = test_split[test_split < len(cls_test_folds)]
                cls_test_folds[test_split] = test_fold_indices
                test_folds[y == cls] = cls_test_folds
        return test_folds
    def _iter_test_masks(self, X, y=None, labels=None):
        test_folds = self._make_test_folds(X, y)
        for i in range(self.n_folds):
            yield test_folds == i
    def split(self, X, y, labels=None):
        return super(StratifiedKFold, self).split(X, y, labels)
class LeaveOneLabelOut(BaseCrossValidator):
    def _iter_test_masks(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        labels = np.array(labels, copy=True)
        unique_labels = np.unique(labels)
        for i in unique_labels:
            yield labels == i
    def get_n_splits(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        return len(np.unique(labels))
class LeavePLabelOut(BaseCrossValidator):
    def __init__(self, n_labels):
        self.n_labels = n_labels
    def _iter_test_masks(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        labels = np.array(labels, copy=True)
        unique_labels = np.unique(labels)
        combi = combinations(range(len(unique_labels)), self.n_labels)
        for indices in combi:
            test_index = np.zeros(_num_samples(X), dtype=np.bool)
            for l in unique_labels[np.array(indices)]:
                test_index[labels == l] = True
            yield test_index
    def get_n_splits(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        return int(comb(len(np.unique(labels)), self.n_labels, exact=True))
class BaseShuffleSplit(with_metaclass(ABCMeta)):
    def __init__(self, n_iter=10, test_size=0.1, train_size=None,
                 random_state=None):
        _validate_shuffle_split_init(test_size, train_size)
        self.n_iter = n_iter
        self.test_size = test_size
        self.train_size = train_size
        self.random_state = random_state
    def split(self, X, y=None, labels=None):
        X, y, labels = indexable(X, y, labels)
        for train, test in self._iter_indices(X, y, labels):
            yield train, test
    @abstractmethod
    def _iter_indices(self, X, y=None, labels=None):
    def get_n_splits(self, X=None, y=None, labels=None):
        return self.n_iter
    def __repr__(self):
        return _build_repr(self)
class ShuffleSplit(BaseShuffleSplit):
    def _iter_indices(self, X, y=None, labels=None):
        n_samples = _num_samples(X)
        n_train, n_test = _validate_shuffle_split(n_samples, self.test_size,
                                                  self.train_size)
        rng = check_random_state(self.random_state)
        for i in range(self.n_iter):
            permutation = rng.permutation(n_samples)
            ind_test = permutation[:n_test]
            ind_train = permutation[n_test:(n_test + n_train)]
            yield ind_train, ind_test
class LabelShuffleSplit(ShuffleSplit):
    def __init__(self, n_iter=5, test_size=0.2, train_size=None,
                 random_state=None):
        super(LabelShuffleSplit, self).__init__(
            n_iter=n_iter,
            test_size=test_size,
            train_size=train_size,
            random_state=random_state)
    def _iter_indices(self, X, y, labels):
        if labels is None:
            raise ValueError("The labels parameter should not be None")
        classes, label_indices = np.unique(labels, return_inverse=True)
        for label_train, label_test in super(
                LabelShuffleSplit, self)._iter_indices(X=classes):
            train = np.flatnonzero(np.in1d(label_indices, label_train))
            test = np.flatnonzero(np.in1d(label_indices, label_test))
            yield train, test
class StratifiedShuffleSplit(BaseShuffleSplit):
    def __init__(self, n_iter=10, test_size=0.1, train_size=None,
                 random_state=None):
        super(StratifiedShuffleSplit, self).__init__(
            n_iter, test_size, train_size, random_state)
    def _iter_indices(self, X, y, labels=None):
        n_samples = _num_samples(X)
        n_train, n_test = _validate_shuffle_split(n_samples, self.test_size,
                                                  self.train_size)
        classes, y_indices = np.unique(y, return_inverse=True)
        n_classes = classes.shape[0]
        class_counts = bincount(y_indices)
        if np.min(class_counts) < 2:
            raise ValueError("The least populated class in y has only 1"
                             " member, which is too few. The minimum"
                             " number of labels for any class cannot"
                             " be less than 2.")
        if n_train < n_classes:
            raise ValueError('The train_size = %d should be greater or '
                             'equal to the number of classes = %d' %
                             (n_train, n_classes))
        if n_test < n_classes:
            raise ValueError('The test_size = %d should be greater or '
                             'equal to the number of classes = %d' %
                             (n_test, n_classes))
        rng = check_random_state(self.random_state)
        p_i = class_counts / float(n_samples)
        n_i = np.round(n_train * p_i).astype(int)
        t_i = np.minimum(class_counts - n_i,
                         np.round(n_test * p_i).astype(int))
        for _ in range(self.n_iter):
            train = []
            test = []
            for i, class_i in enumerate(classes):
                permutation = rng.permutation(class_counts[i])
                perm_indices_class_i = np.where((y == class_i))[0][permutation]
                train.extend(perm_indices_class_i[:n_i[i]])
                test.extend(perm_indices_class_i[n_i[i]:n_i[i] + t_i[i]])
            if len(train) + len(test) < n_train + n_test:
                missing_indices = np.where(bincount(train + test,
                                                    minlength=len(y)) == 0)[0]
                missing_indices = rng.permutation(missing_indices)
                n_missing_train = n_train - len(train)
                n_missing_test = n_test - len(test)
                if n_missing_train > 0:
                    train.extend(missing_indices[:n_missing_train])
                if n_missing_test > 0:
                    test.extend(missing_indices[-n_missing_test:])
            train = rng.permutation(train)
            test = rng.permutation(test)
            yield train, test
    def split(self, X, y, labels=None):
        return super(StratifiedShuffleSplit, self).split(X, y, labels)
def _validate_shuffle_split_init(test_size, train_size):
    if test_size is None and train_size is None:
        raise ValueError('test_size and train_size can not both be None')
    if test_size is not None:
        if np.asarray(test_size).dtype.kind == 'f':
            if test_size >= 1.:
                raise ValueError(
                    'test_size=%f should be smaller '
                    'than 1.0 or be an integer' % test_size)
        elif np.asarray(test_size).dtype.kind != 'i':
            raise ValueError("Invalid value for test_size: %r" % test_size)
    if train_size is not None:
        if np.asarray(train_size).dtype.kind == 'f':
            if train_size >= 1.:
                raise ValueError("train_size=%f should be smaller "
                                 "than 1.0 or be an integer" % train_size)
            elif (np.asarray(test_size).dtype.kind == 'f' and
                    (train_size + test_size) > 1.):
                raise ValueError('The sum of test_size and train_size = %f, '
                                 'should be smaller than 1.0. Reduce '
                                 'test_size and/or train_size.' %
                                 (train_size + test_size))
        elif np.asarray(train_size).dtype.kind != 'i':
            raise ValueError("Invalid value for train_size: %r" % train_size)
def _validate_shuffle_split(n_samples, test_size, train_size):
    if (test_size is not None and np.asarray(test_size).dtype.kind == 'i'
            and test_size >= n_samples):
        raise ValueError('test_size=%d should be smaller than the number of '
                         'samples %d' % (test_size, n_samples))
    if (train_size is not None and np.asarray(train_size).dtype.kind == 'i'
            and train_size >= n_samples):
        raise ValueError("train_size=%d should be smaller than the number of"
                         " samples %d" % (train_size, n_samples))
    if np.asarray(test_size).dtype.kind == 'f':
        n_test = ceil(test_size * n_samples)
    elif np.asarray(test_size).dtype.kind == 'i':
        n_test = float(test_size)
    if train_size is None:
        n_train = n_samples - n_test
    elif np.asarray(train_size).dtype.kind == 'f':
        n_train = floor(train_size * n_samples)
    else:
        n_train = float(train_size)
    if test_size is None:
        n_test = n_samples - n_train
    if n_train + n_test > n_samples:
        raise ValueError('The sum of train_size and test_size = %d, '
                         'should be smaller than the number of '
                         'samples %d. Reduce test_size and/or '
                         'train_size.' % (n_train + n_test, n_samples))
    return int(n_train), int(n_test)
class PredefinedSplit(BaseCrossValidator):
    def __init__(self, test_fold):
        self.test_fold = np.array(test_fold, dtype=np.int)
        self.test_fold = column_or_1d(self.test_fold)
        self.unique_folds = np.unique(self.test_fold)
        self.unique_folds = self.unique_folds[self.unique_folds != -1]
    def split(self, X=None, y=None, labels=None):
        ind = np.arange(len(self.test_fold))
        for test_index in self._iter_test_masks():
            train_index = ind[np.logical_not(test_index)]
            test_index = ind[test_index]
            yield train_index, test_index
    def _iter_test_masks(self):
        for f in self.unique_folds:
            test_index = np.where(self.test_fold == f)[0]
            test_mask = np.zeros(len(self.test_fold), dtype=np.bool)
            test_mask[test_index] = True
            yield test_mask
    def get_n_splits(self, X=None, y=None, labels=None):
        return len(self.unique_folds)
class _CVIterableWrapper(BaseCrossValidator):
    def __init__(self, cv):
        self.cv = cv
    def get_n_splits(self, X=None, y=None, labels=None):
        return len(self.cv)
    def split(self, X=None, y=None, labels=None):
        for train, test in self.cv:
            yield train, test
def check_cv(cv=3, y=None, classifier=False):
    if cv is None:
        cv = 3
    if isinstance(cv, numbers.Integral):
        if (classifier and (y is not None) and
                (type_of_target(y) in ('binary', 'multiclass'))):
            return StratifiedKFold(cv)
        else:
            return KFold(cv)
    if not hasattr(cv, 'split') or isinstance(cv, str):
        if not isinstance(cv, Iterable) or isinstance(cv, str):
            raise ValueError("Expected cv as an integer, cross-validation "
                             "object (from sklearn.model_selection) "
                             "or an iterable. Got %s." % cv)
        return _CVIterableWrapper(cv)
    return cv
def train_test_split(*arrays, **options):
    n_arrays = len(arrays)
    if n_arrays == 0:
        raise ValueError("At least one array required as input")
    test_size = options.pop('test_size', None)
    train_size = options.pop('train_size', None)
    random_state = options.pop('random_state', None)
    stratify = options.pop('stratify', None)
    if options:
        raise TypeError("Invalid parameters passed: %s" % str(options))
    if test_size is None and train_size is None:
        test_size = 0.25
    arrays = indexable(*arrays)
    if stratify is not None:
        CVClass = StratifiedShuffleSplit
    else:
        CVClass = ShuffleSplit
    cv = CVClass(test_size=test_size,
                 train_size=train_size,
                 random_state=random_state)
    train, test = next(cv.split(X=arrays[0], y=stratify))
    return list(chain.from_iterable((safe_indexing(a, train),
                                     safe_indexing(a, test)) for a in arrays))
train_test_split.__test__ = False
def _safe_split(estimator, X, y, indices, train_indices=None):
    if (hasattr(estimator, 'kernel') and callable(estimator.kernel) and
            not isinstance(estimator.kernel, GPKernel)):
        raise ValueError("Cannot use a custom kernel function. "
                         "Precompute the kernel matrix instead.")
    if not hasattr(X, "shape"):
        if getattr(estimator, "_pairwise", False):
            raise ValueError("Precomputed kernels or affinity matrices have "
                             "to be passed as arrays or sparse matrices.")
        X_subset = [X[index] for index in indices]
    else:
        if getattr(estimator, "_pairwise", False):
            if X.shape[0] != X.shape[1]:
                raise ValueError("X should be a square kernel matrix")
            if train_indices is None:
                X_subset = X[np.ix_(indices, indices)]
            else:
                X_subset = X[np.ix_(indices, train_indices)]
        else:
            X_subset = safe_indexing(X, indices)
    if y is not None:
        y_subset = safe_indexing(y, indices)
    else:
        y_subset = None
    return X_subset, y_subset
def _build_repr(self):
    cls = self.__class__
    init = getattr(cls.__init__, 'deprecated_original', cls.__init__)
    init_signature = signature(init)
    if init is object.__init__:
        args = []
    else:
        args = sorted([p.name for p in init_signature.parameters.values()
                       if p.name != 'self' and p.kind != p.VAR_KEYWORD])
    class_name = self.__class__.__name__
    params = dict()
    for key in args:
        warnings.simplefilter("always", DeprecationWarning)
        try:
            with warnings.catch_warnings(record=True) as w:
                value = getattr(self, key, None)
            if len(w) and w[0].category == DeprecationWarning:
                continue
        finally:
            warnings.filters.pop(0)
        params[key] = value
    return '%s(%s)' % (class_name, _pprint(params, offset=len(class_name)))