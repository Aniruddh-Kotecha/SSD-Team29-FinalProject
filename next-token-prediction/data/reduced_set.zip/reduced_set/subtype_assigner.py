from lib2to3 import pytree
from lib2to3.pgen2 import token
from lib2to3.pygram import python_symbols as syms
from yapf.yapflib import format_token
from yapf.yapflib import pytree_utils
from yapf.yapflib import pytree_visitor
from yapf.yapflib import style
def AssignSubtypes(tree):
  subtype_assigner = _SubtypeAssigner()
  subtype_assigner.Visit(tree)
_ARGLIST_TOKEN_TO_SUBTYPE = {
    '=': format_token.Subtype.DEFAULT_OR_NAMED_ASSIGN,
    '*': format_token.Subtype.VARARGS_STAR,
    '**': format_token.Subtype.KWARGS_STAR_STAR,
}
class _SubtypeAssigner(pytree_visitor.PyTreeVisitor):
  def Visit_dictsetmaker(self, node):
    dict_maker = False
    if len(node.children) > 1:
      index = 0
      while index < len(node.children):
        if pytree_utils.NodeName(node.children[index]) != 'COMMENT':
          break
        index += 1
      if index < len(node.children):
        child = node.children[index + 1]
        dict_maker = isinstance(child, pytree.Leaf) and child.value == ':'
    last_was_comma = False
    last_was_colon = False
    for child in node.children:
      if pytree_utils.NodeName(child) == 'comp_for':
        self._AppendFirstLeafTokenSubtype(
            child, format_token.Subtype.DICT_SET_GENERATOR)
      else:
        if dict_maker:
          if last_was_comma:
            self._AppendFirstLeafTokenSubtype(
                child, format_token.Subtype.DICTIONARY_KEY)
          elif last_was_colon:
            if pytree_utils.NodeName(child) == 'power':
              self._AppendSubtypeRec(child, format_token.Subtype.NONE)
            else:
              self._AppendFirstLeafTokenSubtype(
                  child, format_token.Subtype.DICTIONARY_VALUE)
            if style.Get('INDENT_DICTIONARY_VALUE'):
              _InsertPseudoParentheses(child)
        last_was_comma = isinstance(child, pytree.Leaf) and child.value == ','
        last_was_colon = isinstance(child, pytree.Leaf) and child.value == ':'
      self.Visit(child)
  def Visit_expr_stmt(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '=':
        self._AppendTokenSubtype(child, format_token.Subtype.ASSIGN_OPERATOR)
  def Visit_or_test(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == 'or':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_and_test(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == 'and':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_not_test(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == 'not':
        self._AppendTokenSubtype(child, format_token.Subtype.UNARY_OPERATOR)
  def Visit_comparison(self, node):
    for child in node.children:
      self.Visit(child)
      if (isinstance(child, pytree.Leaf) and child.value in {
          '<', '>', '==', '>=', '<=', '<>', '!=', 'in', 'not in', 'is', 'is not'
      }):
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_star_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '*':
        self._AppendTokenSubtype(child, format_token.Subtype.UNARY_OPERATOR)
  def Visit_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '|':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_xor_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '^':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_and_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '&':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_shift_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value in {'<<', '>>'}:
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_arith_expr(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value in '+-':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_term(self, node):
    for child in node.children:
      self.Visit(child)
      if (isinstance(child, pytree.Leaf) and
          child.value in {'*', '/', '%', '//'}):
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_factor(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value in '+-~':
        self._AppendTokenSubtype(child, format_token.Subtype.UNARY_OPERATOR)
  def Visit_power(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == '**':
        self._AppendTokenSubtype(child, format_token.Subtype.BINARY_OPERATOR)
  def Visit_subscript(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == ':':
        self._AppendTokenSubtype(child, format_token.Subtype.SUBSCRIPT_COLON)
  def Visit_sliceop(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf) and child.value == ':':
        self._AppendTokenSubtype(child, format_token.Subtype.SUBSCRIPT_COLON)
  def Visit_argument(self, node):
    self._ProcessArgLists(node)
  def Visit_arglist(self, node):
    self._ProcessArgLists(node)
    self._SetDefaultOrNamedAssignArgListSubtype(node)
  def Visit_typedargslist(self, node):
    self._ProcessArgLists(node)
    self._SetDefaultOrNamedAssignArgListSubtype(node)
  def Visit_varargslist(self, node):
    self._ProcessArgLists(node)
    self._SetDefaultOrNamedAssignArgListSubtype(node)
  def Visit_comp_for(self, node):
    self._AppendSubtypeRec(node, format_token.Subtype.COMP_FOR)
    self.DefaultNodeVisit(node)
  def Visit_comp_if(self, node):
    self._AppendSubtypeRec(node, format_token.Subtype.COMP_IF)
    self.DefaultNodeVisit(node)
  def _ProcessArgLists(self, node):
    for child in node.children:
      self.Visit(child)
      if isinstance(child, pytree.Leaf):
        self._AppendTokenSubtype(child,
                                 subtype=_ARGLIST_TOKEN_TO_SUBTYPE.get(
                                     child.value, format_token.Subtype.NONE),
                                 force=False)
  def _AppendSubtypeRec(self, node, subtype, force=True):
    if isinstance(node, pytree.Leaf):
      self._AppendTokenSubtype(node, subtype, force=force)
      return
    for child in node.children:
      self._AppendSubtypeRec(child, subtype, force=force)
  def _AppendTokenSubtype(self, node, subtype, force=True):
    pytree_utils.AppendNodeAnnotation(node, pytree_utils.Annotation.SUBTYPE,
                                      subtype)
  def _AppendFirstLeafTokenSubtype(self, node, subtype, force=False):
    if isinstance(node, pytree.Leaf):
      self._AppendTokenSubtype(node, subtype, force=force)
      return
    self._AppendFirstLeafTokenSubtype(node.children[0], subtype, force=force)
  def _SetDefaultOrNamedAssignArgListSubtype(self, node):
    def HasDefaultOrNamedAssignSubtype(node):
      if isinstance(node, pytree.Leaf):
        if (format_token.Subtype.DEFAULT_OR_NAMED_ASSIGN in
            pytree_utils.GetNodeAnnotation(
                node, pytree_utils.Annotation.SUBTYPE, set())):
          return True
        return False
      has_subtype = False
      for child in node.children:
        has_subtype |= HasDefaultOrNamedAssignSubtype(child)
      return has_subtype
    if HasDefaultOrNamedAssignSubtype(node):
      for child in node.children:
        if pytree_utils.NodeName(child) != 'COMMA':
          self._AppendFirstLeafTokenSubtype(
              child, format_token.Subtype.DEFAULT_OR_NAMED_ASSIGN_ARG_LIST)
def _InsertPseudoParentheses(node):
  comment_node = None
  if isinstance(node, pytree.Node):
    if pytree_utils.NodeName(node.children[-1]) == 'COMMENT':
      comment_node = node.children[-1].clone()
      node.children[-1].remove()
  first = _GetFirstLeafNode(node)
  last = _GetLastLeafNode(node)
  lparen = pytree.Leaf(token.LPAR,
                       u'(',
                       context=('', (first.get_lineno(), first.column - 1)))
  rparen = pytree.Leaf(token.RPAR,
                       u')',
                       context=('', (last.get_lineno(),
                                     last.column + len(last.value) + 1)))
  lparen.is_pseudo = True
  rparen.is_pseudo = True
  if isinstance(node, pytree.Node):
    node.insert_child(0, lparen)
    node.append_child(rparen)
    if comment_node:
      node.append_child(comment_node)
  else:
    new_node = pytree.Node(syms.atom, [lparen, node.clone(), rparen])
    node.replace(new_node)
def _GetFirstLeafNode(node):
  if isinstance(node, pytree.Leaf):
    return node
  return _GetFirstLeafNode(node.children[0])
def _GetLastLeafNode(node):
  if isinstance(node, pytree.Leaf):
    return node
  return _GetLastLeafNode(node.children[-1])