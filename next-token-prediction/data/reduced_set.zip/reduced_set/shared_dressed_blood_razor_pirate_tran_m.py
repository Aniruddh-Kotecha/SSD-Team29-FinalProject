from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_blood_razor_pirate_tran_m.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","trandoshan_base_male")		
	return result