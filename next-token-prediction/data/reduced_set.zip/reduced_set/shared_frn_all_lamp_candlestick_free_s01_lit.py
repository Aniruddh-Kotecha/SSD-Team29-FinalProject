from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/furniture/all/shared_frn_all_lamp_candlestick_free_s01_lit.iff"
	result.attribute_template_id = 6
	result.stfName("frn_n","frn_lamp_candlestick")		
	return result