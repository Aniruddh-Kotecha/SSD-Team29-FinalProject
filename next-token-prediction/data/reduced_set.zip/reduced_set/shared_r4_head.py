from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/structure/general/shared_r4_head.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result