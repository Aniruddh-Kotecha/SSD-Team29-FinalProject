from __future__ import (division, absolute_import, print_function,
                        unicode_literals)
from collections import defaultdict
import operator
import os
from . import SimIndex
from ..exceptions import *
class SimIndexCollection(SimIndex):
    def __init__(self, shards=(), root=True):
        super(SimIndexCollection, self).__init__()
        self._shards = []
        self.shard_func = self.default_shard_func
        self._name_to_docid_map = {}
        self._docid_to_name_map = {}
        self._df_map = {}
        self._dirty = False
        self.set_config('root', root, passthrough=False)
        if shards:
            self.add_shards(*shards)
    def set_config(self, key, value, passthrough=True):
        super(SimIndexCollection, self).set_config(key, value)
        if passthrough:
            for shard in self._shards:
                shard.set_config(key, value)
    def update_config(self, passthrough=True, **d):
        super(SimIndexCollection, self).update_config(**d)
        if passthrough:
            for shard in self._shards:
                shard.update_config(**d)
    def clear_shards(self):
        self._shards = []
    def add_shards(self, *sim_index_shards):
        for shard in sim_index_shards:
            shard.update_config(**self._config)
        self._shards.extend(sim_index_shards)
        self.update_trigger_helper()
    _salt = None
    def default_shard_func(self, shard_key):
        if self._salt is None:
            self._salt = os.urandom(4)
        return hash(str(shard_key)+self._salt) % len(self._shards)
    def set_shard_func(self, func):
        self._shard_func = func
    def set_global_N(self, N):
        for shard in self._shards:
            shard.set_global_N(N)
    def set_global_df_map(self, df_map):
        for shard in self._shards:
            shard.set_global_df_map(df_map)
    def get_local_df_map(self):
        return self._df_map
    def get_name_to_docid_map(self):
        return self._name_to_docid_map
    def update_trigger(method):
        def wrapper(self, *args, **kwargs):
            self._dirty = True
            val = method(self, *args, **kwargs)
            if self._dirty:
                self.update_trigger_helper()
                self._dirty = False
        return wrapper
    @update_trigger
    def index_files(self, named_files):
        named_string_buffers = [(name, file.read())
            for (name, file) in named_files]
        self.index_string_buffers(named_string_buffers)
    @update_trigger
    def index_string_buffers(self, named_string_buffers):
        sharded_input_map = defaultdict(list)
        for (name, buffer) in named_string_buffers:
            sharded_input_map[self.shard_func(name)].append((name, buffer))
        for shard_id in sharded_input_map:
            self._shards[shard_id].index_string_buffers(
                sharded_input_map[shard_id]
            )
    @update_trigger
    def index_urls(self, *urls):
        sharded_input_map = defaultdict(list)
        for url in urls:
            sharded_input_map[self.shard_func(url)].append(url)
        for shard_id in sharded_input_map:
            self._shards[shard_id].index_urls(
                *sharded_input_map[shard_id]
            )
    @update_trigger
    def del_docids(self, *docids):
        sharded_del_map = defaultdict(list)
        for docid in docids:
            assert '-' in docid
            (shard_id, sep, remote_docid) = docid.partition('-')
            shard_id = int(shard_id)
            if '-' not in remote_docid:
                remote_docid = int(remote_docid)
            sharded_del_map[shard_id].append(remote_docid)
        for (shard_id, remote_docids) in sharded_del_map.items():
            self._shards[shard_id].del_docids(*remote_docids)
    @staticmethod
    def make_node_docid(shard_id, docid):
        return "{}-{}".format(shard_id, docid)
    def docid_to_name(self, docid):
        return self._docid_to_name_map[docid]
    def name_to_docid(self, name):
        return self._name_to_docid_map[name]
    def postings_list(self, term):
        merged_postings_list = []
        for shard_id in range(len(self._shards)):
            merged_postings_list.extend(
                 [(self.make_node_docid(shard_id, docid), freq) for
                  (docid, freq) in self._shards[shard_id].postings_list(term)]
                )
        return merged_postings_list
    def set_query_scorer(self, query_scorer):
        for shard in self._shards:
            shard.set_query_scorer(query_scorer)
    def _query(self, query_vec):
        results = []
        for shard in self._shards:
            results.extend(shard.query(query_vec))
        results.sort(key=operator.itemgetter(1), reverse=True)
        return results
    def update_trigger_helper(self):
        self.update_node_stats()
        if self.config('root'):
            self.broadcast_node_stats()
    def update_node_stats(self):
        def merge_df_map(target, source):
            for (term, df) in source.items():
                if term not in target: target[term] = 0
                target[term] += df
        self._N = 0
        self._df_map = {}
        name_to_docid_maps = {}
        for shard_id in range(len(self._shards)):
            shard = self._shards[shard_id]
            self._N += shard.get_local_N()
            merge_df_map(self._df_map, shard.get_local_df_map())
            name_to_docid_maps[shard_id] = shard.get_name_to_docid_map()
        for (shard_id, name_to_docid_map) in name_to_docid_maps.iteritems():
            for (name, docid) in name_to_docid_map.iteritems():
                gdocid = self.make_node_docid(shard_id, docid)
                self._name_to_docid_map[name] = gdocid
                self._docid_to_name_map[gdocid] = name
    def broadcast_node_stats(self):  
        for shard in self._shards:
            shard.set_global_N(self._N)
            shard.set_global_df_map(self._df_map)