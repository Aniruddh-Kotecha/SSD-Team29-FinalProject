from __future__ import absolute_import
import gslib.tests.testcase as testcase
from gslib.tests.testcase.integration_testcase import SkipForS3
from gslib.tests.util import ObjectToURI as suri
@SkipForS3('Logging command requires S3 ACL configuration on target bucket.')
class TestLogging(testcase.GsUtilIntegrationTestCase):
  _enable_log_cmd = ['logging', 'set', 'on']
  _disable_log_cmd = ['logging', 'set', 'off']
  _get_log_cmd = ['logging', 'get']
  def testLogging(self):
    bucket_uri = self.CreateBucket()
    bucket_suri = suri(bucket_uri)
    stderr = self.RunGsUtil(
        self._enable_log_cmd + ['-b', bucket_suri, bucket_suri],
        return_stderr=True)
    self.assertIn('Enabling logging', stderr)
    stdout = self.RunGsUtil(self._get_log_cmd + [bucket_suri],
                            return_stdout=True)
    self.assertIn('LogObjectPrefix'.lower(), stdout.lower())
    stderr = self.RunGsUtil(self._disable_log_cmd + [bucket_suri],
                            return_stderr=True)
    self.assertIn('Disabling logging', stderr)
  def testTooFewArgumentsFails(self):
    stderr = self.RunGsUtil(self._enable_log_cmd, return_stderr=True,
                            expected_status=1)
    self.assertIn('command requires at least', stderr)
    stderr = self.RunGsUtil(self._disable_log_cmd, return_stderr=True,
                            expected_status=1)
    self.assertIn('command requires at least', stderr)
    stderr = self.RunGsUtil(self._get_log_cmd, return_stderr=True,
                            expected_status=1)
    self.assertIn('command requires at least', stderr)
    stderr = self.RunGsUtil(['logging'], return_stderr=True, expected_status=1)
    self.assertIn('command requires at least', stderr)
class TestLoggingOldAlias(TestLogging):
  _enable_log_cmd = ['enablelogging']
  _disable_log_cmd = ['disablelogging']
  _get_log_cmd = ['getlogging']