from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/base/shared_lair_base_nest_ground_lg_dark.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","generic_nest")		
	return result