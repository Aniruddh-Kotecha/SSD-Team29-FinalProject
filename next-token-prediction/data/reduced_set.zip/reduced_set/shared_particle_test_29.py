from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/particle/shared_particle_test_29.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result