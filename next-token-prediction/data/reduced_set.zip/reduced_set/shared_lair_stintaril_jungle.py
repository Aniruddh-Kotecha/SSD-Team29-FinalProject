from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/stintaril/shared_lair_stintaril_jungle.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","stintaril_jungle")		
	return result