from twisted.trial import unittest
from twisted.protocols import finger
from twisted.test.proto_helpers import StringTransport
class FingerTestCase(unittest.TestCase):
    def setUp(self):
        self.transport = StringTransport()
        self.protocol = finger.Finger()
        self.protocol.makeConnection(self.transport)
    def test_simple(self):
        self.protocol.dataReceived("moshez\r\n")
        self.assertEqual(
            self.transport.value(),
            "Login: moshez\nNo such user\n")
    def test_simpleW(self):
        self.protocol.dataReceived("/w moshez\r\n")
        self.assertEqual(
            self.transport.value(),
            "Login: moshez\nNo such user\n")
    def test_forwarding(self):
        self.protocol.dataReceived("moshez@example.com\r\n")
        self.assertEqual(
            self.transport.value(),
            "Finger forwarding service denied\n")
    def test_list(self):
        self.protocol.dataReceived("\r\n")
        self.assertEqual(
            self.transport.value(),
            "Finger online list denied\n")