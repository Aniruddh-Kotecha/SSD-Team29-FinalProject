from client import exceptions
from client.sources.common import core, interpreter
from client.sources.ok_test import doctest
from client.utils import format
from client.utils import timer
import importlib
import os
import re
import subprocess
class SqliteConsole(interpreter.Console):
    PS1 = 'sqlite> '
    PS2 = '   ...> '
    VERSION = (3, 8, 3)
    ordered = False
    def load(self, code, setup='', teardown=''):
        super().load(code, setup, teardown)
    def interpret(self):
        env = dict(os.environ,
                   PATH=os.getcwd() + os.pathsep + os.environ['PATH'])
        if self._has_sqlite_cli(env):
            try:
                test, expected, actual = self._use_sqlite_cli(env)
            except interpreter.ConsoleException:
                return False
            print(format.indent(test, 'sqlite> '))
            print(actual)
            try:
                self._diff_output(expected, actual)
                return True
            except interpreter.ConsoleException:
                return False
        else:
            print('ERROR: could not run sqlite3.')
            print('Tests will not pass, but you can still submit your assignment.')
            print('Please download the newest version of sqlite3 into this folder')
            print('to run tests.')
            return False
    def interact(self):
    def _diff_output(self, expected, actual):
        expected = expected.split('\n')
        actual = actual.split('\n')
        if self.ordered:
            correct = expected == actual
        else:
            correct = sorted(expected) == sorted(actual)
        if not correct:
            print()
            error_msg = '
            if self.ordered:
                error_msg += ' ordered output'
            print(error_msg)
            print('\n'.join('
                            for line in expected))
            print('
            print('\n'.join('
                            for line in actual))
            raise interpreter.ConsoleException
    def _has_sqlite_cli(self, env):
        try:
            version = subprocess.check_output(['sqlite3', '--version'],
                                              env=env).decode()
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
        version = version.split(' ')[0].split('.')
        version_info = tuple(int(num) for num in version)
        return version_info >= self.VERSION
    def _use_sqlite_cli(self, env):
        test = []
        expected = []
        for line in self._setup + self._code + self._teardown:
            if isinstance(line, interpreter.CodeAnswer):
                expected.extend(line.output)
            elif line.startswith(self.PS1):
                test.append(line[len(self.PS1):])
            elif line.startswith(self.PS2):
                test.append(line[len(self.PS2):])
        test = '\n'.join(test)
        process = subprocess.Popen(['sqlite3'],
                                    universal_newlines=True,
                                    stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    env=env)
        try:
            result, error = process.communicate(test, timeout=self.timeout)
        except subprocess.TimeoutExpired as e:
            process.kill()
            print('
            raise interpreter.ConsoleException(exceptions.Timeout(self.timeout))
        return test, '\n'.join(expected), (error + '\n' + result).strip()
class SqliteSuite(doctest.DoctestSuite):
    console_type = SqliteConsole
    ordered = core.Boolean(default=False)
    def __init__(self, verbose, interactive, timeout=None, **fields):
        super().__init__(verbose, interactive, timeout, **fields)
        self.console.ordered = fields.get('ordered', False)