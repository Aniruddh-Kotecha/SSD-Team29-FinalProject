__test__ = False
from time import sleep
from stdnet import StructureFieldError
from stdnet.utils import test, populate, zip, to_string
class StringData(test.DataGenerator):
    def generate(self):
        self.names = self.populate()
class MultiFieldMixin(object):
    attrname = 'data'
    data_cls = StringData
    def setUp(self):
        self.names = test.populate('string', size=10)
        self.name = self.names[0]
    def defaults(self):
        return {}
    def get_object_and_field(self, save=True, **kwargs):
        models = self.mapper
        params = self.defaults()
        params.update(kwargs)
        m = self.model(**params)
        if save:
            yield models.session().add(m)
        yield m, getattr(m, self.attrname)
    def adddata(self, obj):
        raise NotImplementedError
    def test_RaiseStructFieldError(self):
        yield self.async.assertRaises(StructureFieldError,
                                      self.get_object_and_field, False)
    def test_multi_field_meta(self):
        models = self.mapper
        obj, field = yield self.get_object_and_field()
        self.assertTrue(field.field)
        self.assertEqual(field.field.model, self.model)
        self.assertEqual(field._pkvalue, obj.pkvalue())
        self.assertEqual(field.session, obj.session)
        be = field.backend_structure()
        self.assertEqual(be.backend, models[self.model].backend)
        self.assertEqual(be.instance, field)
        if be.backend.name == 'redis':
            yield self.check_redis_structure(obj, be)
    def check_redis_structure(self, obj, be):
        session = obj.session
        backend = be.backend
        keys = backend.instance_keys(obj)
        self.assertTrue(be.id in keys)
        lkeys = yield backend.model_keys(self.model._meta)
        self.assertFalse(be.id in lkeys)
        yield self.adddata(obj)
        if backend.name == 'redis':
            lkeys = yield backend.model_keys(self.model._meta)
            self.assertTrue(be.id in lkeys)
        yield session.delete(obj)
        lkeys = yield backend.model_keys(self.model._meta)
        self.assertFalse(be.id in lkeys)