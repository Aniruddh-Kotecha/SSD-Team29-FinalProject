from pyface.qt import QtCore, QtGui
from traits.api import Bool
from traitsui.qt4.table_editor import TableDelegate
class TableImageRenderer(TableDelegate):
    scale_to_cell = Bool(True)
    def get_image_for_obj(self, value, row, col):
        return None
    def paint(self, painter, option, index):
        QtGui.QStyledItemDelegate.paint(self, painter, option, index)
        value = index.data(QtCore.Qt.UserRole)
        image = self.get_image_for_obj(value, index.row(), index.column())
        if image:
            image = image.create_bitmap()
            if self.scale_to_cell:
                w = min(image.width(), option.rect.width())
                h = min(image.height(), option.rect.height())
            else:
                w = image.width()
                h = image.height()
            x = option.rect.x()
            y = option.rect.y() + (option.rect.height()-h)/2
            target = QtCore.QRect(x, y, w, h)
            painter.drawPixmap(target, image)
    def sizeHint(self, option, index):
        size = QtGui.QStyledItemDelegate.sizeHint(self, option, index)
        value = index.data(QtCore.Qt.UserRole)
        image = self.get_image_for_obj(value, index.row(), index.column())
        if image:
            image = image.create_bitmap()
            size.setWidth(max(image.width(), size.width()))
            size.setHeight(max(image.height(), size.height()))
        return size