from SimPEG import Utils, Problem, Maps, np, sp, mkvc
from SimPEG.EM.FDEM.SrcFDEM import BaseSrc as FDEMBaseSrc
from SimPEG.EM.Utils import omega
from scipy.constants import mu_0
from numpy.lib import recfunctions as recFunc
from Utils.sourceUtils import homo1DModelSource
from Utils import rec2ndarr
import sys
class BaseMTSrc(FDEMBaseSrc):
    freq = None
    def __init__(self, rxList, freq):
        self.freq = float(freq)
        FDEMBaseSrc.__init__(self, rxList)
class polxy_1DhomotD(BaseMTSrc):
    def __init__(self, rxList, freq):
        BaseMTSrc.__init__(self, rxList, freq)
class polxy_1Dprimary(BaseMTSrc):
    def __init__(self, rxList, freq):
        self.sigma1d = None
        BaseMTSrc.__init__(self, rxList, freq)
        self._ePrimary = None
    def ePrimary(self,problem):
        if self.sigma1d is None:
            if len(problem._sigmaPrimary) == problem.mesh.nC:
                if problem.mesh.dim == 1:
                    self.sigma1d = problem.mesh.r(problem._sigmaPrimary,'CC','CC','M')[:]
                elif problem.mesh.dim == 3:
                    self.sigma1d = problem.mesh.r(problem._sigmaPrimary,'CC','CC','M')[0,0,:]
            elif len(problem._sigmaPrimary) == problem.mesh.nCz:
                self.sigma1d = problem._sigmaPrimary
        if self._ePrimary is None:
            self._ePrimary = homo1DModelSource(problem.mesh,self.freq,self.sigma1d)
        return self._ePrimary
    def bPrimary(self,problem):
        if problem.mesh.dim == 1:
            C = problem.mesh.nodalGrad
        elif problem.mesh.dim == 3:
            C = problem.mesh.edgeCurl
        bBG_bp = (- C * self.ePrimary(problem) )*(1/( 1j*omega(self.freq) ))
        return bBG_bp
    def S_e(self,problem):
        e_p = self.ePrimary(problem)
        Map_sigma_p = Maps.Vertical1DMap(problem.mesh)
        sigma_p = Map_sigma_p._transform(self.sigma1d)
        if problem.mesh.dim == 1:
            Mesigma = problem.mesh.getFaceInnerProduct(problem.curModel.sigma)
            Mesigma_p = problem.mesh.getFaceInnerProduct(sigma_p)
        if problem.mesh.dim == 2:
            pass
        if problem.mesh.dim == 3:
            Mesigma = problem.MeSigma
            Mesigma_p = problem.mesh.getEdgeInnerProduct(sigma_p)
        return (Mesigma - Mesigma_p) * e_p
    def S_eDeriv_m(self, problem, v, adjoint = False):
        if problem.mesh.dim == 1:
            MsigmaDeriv = problem.mesh.getFaceInnerProductDeriv(problem.curModel.sigma)(self.ePrimary(problem)[:,1]) * problem.curModel.sigmaDeriv
        if problem.mesh.dim == 2:
            pass
        if problem.mesh.dim == 3:
            ePri = self.ePrimary(problem)
            if adjoint:
                return sp.hstack(( problem.MeSigmaDeriv(ePri[:,0]).T, problem.MeSigmaDeriv(ePri[:,1]).T ))*v
            else:
                return np.hstack(( mkvc(problem.MeSigmaDeriv(ePri[:,0]) * v,2), mkvc(problem.MeSigmaDeriv(ePri[:,1])*v,2) ))
        if adjoint:
            return MsigmaDeriv.T * v
        else:
            return MsigmaDeriv * v
class polxy_3Dprimary(BaseMTSrc):
    def __init__(self, rxList, freq):
        self.sigmaPrimary = None
        BaseMTSrc.__init__(self, rxList, freq)
        self._ePrimary = None
    def ePrimary(self,problem):
        self.sigmaPrimary = problem._sigmaPrimary
        if self._ePrimary is None:
            self._ePrimary = homo3DModelSource(problem.mesh,self.sigmaPrimary,self.freq)
        return self._ePrimary
    def bPrimary(self,problem):
        if problem.mesh.dim == 1:
            C = problem.mesh.nodalGrad
        elif problem.mesh.dim == 3:
            C = problem.mesh.edgeCurl
        bBG_bp = (- C * self.ePrimary(problem) )*(1/( 1j*omega(self.freq) ))
        return bBG_bp
    def S_e(self,problem):
        e_p = self.ePrimary(problem)
        Map_sigma_p = Maps.Vertical1DMap(problem.mesh)
        sigma_p = Map_sigma_p._transform(self.sigma1d)
        if problem.mesh.dim == 1:
            Mesigma = problem.mesh.getFaceInnerProduct(problem.curModel.sigma)
            Mesigma_p = problem.mesh.getFaceInnerProduct(sigma_p)
        if problem.mesh.dim == 2:
            pass
        if problem.mesh.dim == 3:
            Mesigma = problem.MeSigma
            Mesigma_p = problem.mesh.getEdgeInnerProduct(sigma_p)
        return (Mesigma - Mesigma_p) * e_p
    def S_eDeriv_m(self, problem, v, adjoint = False):
        if problem.mesh.dim == 1:
            MsigmaDeriv = problem.mesh.getFaceInnerProductDeriv(problem.curModel.sigma)(self.ePrimary(problem)[:,1]) * problem.curModel.sigmaDeriv
        if problem.mesh.dim == 2:
            pass
        if problem.mesh.dim == 3:
            ePri = self.ePrimary(problem)
            if adjoint:
                return sp.hstack(( problem.MeSigmaDeriv(ePri[:,0]).T, problem.MeSigmaDeriv(ePri[:,1]).T ))*v
            else:
                return np.hstack(( mkvc(problem.MeSigmaDeriv(ePri[:,0]) * v,2), mkvc(problem.MeSigmaDeriv(ePri[:,1])*v,2) ))
        if adjoint:
            return MsigmaDeriv.T * v
        else:
            return MsigmaDeriv * v