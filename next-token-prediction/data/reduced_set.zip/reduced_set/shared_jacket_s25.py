from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/wearables/jacket/shared_jacket_s25.iff"
	result.attribute_template_id = 11
	result.stfName("wearables_name","jacket_s25")		
	return result