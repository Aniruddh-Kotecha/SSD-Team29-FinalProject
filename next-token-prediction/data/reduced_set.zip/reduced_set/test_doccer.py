from __future__ import division, print_function, absolute_import
import sys
from numpy.testing import assert_equal, dec
from scipy.misc import doccer
DOCSTRINGS_STRIPPED = sys.flags.optimize > 1
docstring = \
param_doc1 = \
param_doc2 = \
param_doc3 = \
doc_dict = {'strtest1':param_doc1,
            'strtest2':param_doc2,
            'strtest3':param_doc3}
filled_docstring = \
def test_unindent():
    yield assert_equal, doccer.unindent_string(param_doc1), param_doc1
    yield assert_equal, doccer.unindent_string(param_doc2), param_doc2
    yield assert_equal, doccer.unindent_string(param_doc3), param_doc1
def test_unindent_dict():
    d2 = doccer.unindent_dict(doc_dict)
    yield assert_equal, d2['strtest1'], doc_dict['strtest1']
    yield assert_equal, d2['strtest2'], doc_dict['strtest2']
    yield assert_equal, d2['strtest3'], doc_dict['strtest1']
def test_docformat():
    udd = doccer.unindent_dict(doc_dict)
    formatted = doccer.docformat(docstring, udd)
    yield assert_equal, formatted, filled_docstring
    single_doc = 'Single line doc %(strtest1)s'
    formatted = doccer.docformat(single_doc, doc_dict)
    yield assert_equal, formatted, 
@dec.skipif(DOCSTRINGS_STRIPPED)
def test_decorator():
    decorator = doccer.filldoc(doc_dict, True)
    @decorator
    def func():
    yield assert_equal, func.__doc__, 
    decorator = doccer.filldoc(doc_dict, False)
    @decorator
    def func():
    yield assert_equal, func.__doc__, 
@dec.skipif(DOCSTRINGS_STRIPPED)
def test_inherit_docstring_from():
    class Foo(object):
        def func(self):
            return
        def func2(self):
    class Bar(Foo):
        @doccer.inherit_docstring_from(Foo)
        def func(self):
            return
        @doccer.inherit_docstring_from(Foo)
        def func2(self):
            return
    assert_equal(Bar.func.__doc__, Foo.func.__doc__ + 'ABC')
    assert_equal(Bar.func2.__doc__, Foo.func2.__doc__)
    bar = Bar()
    assert_equal(bar.func.__doc__, Foo.func.__doc__ + 'ABC')
    assert_equal(bar.func2.__doc__, Foo.func2.__doc__)