__all__ = [
    'InvalidCredentialsException'
]
class InvalidCredentialsException(Exception):
    pass
class NoHostsConnectedToException(Exception):
    pass