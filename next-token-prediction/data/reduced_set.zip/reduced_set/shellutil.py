import os
win32 = (os.name == 'nt')
def ShellEscapeList(words):
  if win32:
    return ' '.join(words)
  s = ''
  for word in words:
    s += "'" + word.replace("'", "'\"'\"'") + "' "
  return s[:-1]
def ShellifyStatus(status):
  if not win32:
    if os.WIFEXITED(status):
      status = os.WEXITSTATUS(status)
    else:
      status = 128 + os.WTERMSIG(status)
  return status