import re
import time
from unittest import TestCase
from txstatsd.metrics.extendedmetrics import ExtendedMetrics
from txstatsd.metrics.metrics import Metrics
class FakeStatsDClient(object):
    def connect(self):
        pass
    def disconnect(self):
        pass
    def write(self, data):
        self.data = data
class TestMetrics(TestCase):
    def setUp(self):
        self.connection = FakeStatsDClient()
        self.metrics = Metrics(self.connection, 'txstatsd.tests')
    def test_gauge(self):
        self.metrics.gauge('gauge', 102)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.gauge:102|g')
    def test_meter(self):
        self.metrics.meter('meter', 3)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.meter:3|m')
    def test_counter(self):
        self.metrics.increment('counter', 18)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.counter:18|c')
        self.metrics.decrement('counter', 9)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.counter:-9|c')
    def test_timing(self):
        self.metrics.timing('timing', 101.1234)
        match = re.match(b'txstatsd.tests.timing:101123.4[0-9]*|ms', self.connection.data)
        self.assertFalse(match is None)
    def test_timing_automatic(self):
        start_time = time.time()
        self.metrics.reset_timing()
        time.sleep(.1)
        self.metrics.timing('timing')
        elapsed = time.time() - start_time
        label, val, units = re.split(b":|\|", self.connection.data)
        self.assertEqual(label, b'txstatsd.tests.timing')
        self.assertEqual(units, b'ms')
        self.assertTrue(100 <= float(val) <= elapsed * 1000)
    def test_timing_automatic_implicit_reset(self):
        start_time = time.time()
        self.metrics.timing('something_else')
        time.sleep(.1)
        self.metrics.timing('timing')
        elapsed = time.time() - start_time
        label, val, units = re.split(b":|\|", self.connection.data)
        self.assertEqual(label, b'txstatsd.tests.timing')
        self.assertEqual(units, b'ms')
        self.assertTrue(100 <= float(val) <= elapsed * 1000)
    def test_generic(self):
        self.metrics.report('users', "pepe", "pd")
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.users:pepe|pd')
    def test_generic_extra(self):
        self.metrics.report('users', "pepe", "pd", 100)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.users:pepe|pd|100')
    def test_empty_namespace(self):
        self.metrics.namespace = None
        self.metrics.gauge('gauge', 213)
        self.assertEqual(self.connection.data,
                         b'gauge:213|g')
        self.metrics.namespace = ''
        self.metrics.gauge('gauge', 413)
        self.assertEqual(self.connection.data,
                         b'gauge:413|g')
class TestExtendedMetrics(TestMetrics):
    def setUp(self):
        super(TestExtendedMetrics, self).setUp()
        self.metrics = ExtendedMetrics(self.connection, 'txstatsd.tests')
    def test_counter(self):
        self.metrics.increment('counter', 18)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.counter:18|c')
        self.metrics.decrement('counter', 9)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.counter:9|c')
    def test_sli(self):
        self.metrics.sli('users', 100)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.users:100|sli')
        self.metrics.sli('users', 200, 2)
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.users:200|sli|2')
        self.metrics.sli_error('users')
        self.assertEqual(self.connection.data,
                         b'txstatsd.tests.users:error|sli')