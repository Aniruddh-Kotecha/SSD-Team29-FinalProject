from world import world, setup_module, teardown_module
import create_source_steps as source_create
import create_dataset_steps as dataset_create
class TestSplitDataset(object):
    def setup(self):
        print "\n-------------------\nTests in: %s\n" % __name__
    def teardown(self):
        print "\nEnd of tests in: %s\n-------------------\n" % __name__
    def test_scenario1(self):
        print self.test_scenario1.__doc__
        examples = [
            ['data/iris.csv', '10', '10', '10', '0.8']]
        for example in examples:
            print "\nTesting with:\n", example
            source_create.i_upload_a_file(self, example[0])
            source_create.the_source_is_finished(self, example[1])
            dataset_create.i_create_a_dataset(self)
            dataset_create.the_dataset_is_finished_in_less_than(self,
                                                                example[2])
            dataset_create.i_create_a_split_dataset(self, example[4])
            dataset_create.the_dataset_is_finished_in_less_than(self,
                                                                example[3])
            dataset_create.i_compare_datasets_instances(self)
            dataset_create.proportion_datasets_instances(self, example[4])