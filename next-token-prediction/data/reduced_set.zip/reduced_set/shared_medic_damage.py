from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/medicine/shared_medic_damage.iff"
	result.attribute_template_id = 7
	result.stfName("medicine_name","medic_damage")		
	return result