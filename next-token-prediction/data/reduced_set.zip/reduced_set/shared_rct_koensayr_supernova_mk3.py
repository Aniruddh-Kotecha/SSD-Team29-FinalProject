from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/reactor/shared_rct_koensayr_supernova_mk3.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","rct_koensayr_supernova_mk3_n")		
	return result