from swgpy.object import *	
def create(kernel):
	result = Ship()
	result.template = "object/ship/shared_hutt_light_s01_tier1.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result