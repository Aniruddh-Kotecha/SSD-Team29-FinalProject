from swgpy.object import *	
def create(kernel):
	result = Intangible()
	result.template = "object/intangible/pet/shared_kliknik_hue.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result