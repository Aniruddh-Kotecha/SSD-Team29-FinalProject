import maya.cmds as cmds
from . import stereoCameraErrors
from . import stereoCameraSets
from . import stereoCameraUtil
import maya.mel as mel
import math
from . import stereoCameraRig
def stereoCameraViewCallback(*args):
    pass
def switchToCameraLeft(cameraName, editor):
    pass
def useCustomBackgroundState(*args):
    pass
def switchToCamera(*args):
    pass
def getValidPanel(editor):
    pass
def initialize():
    pass
def switchToCameraCenter(cameraName, editor):
    pass
def addNewCameraToCurrentSet(rigRoot, panel):
    pass
def checkState(*args):
    pass
def createStereoCameraViewCmdString(command, editor, the_args):
    pass
def toggleUseCustomBackground(*args):
    pass
def switchToCameraRight(cameraName, editor):
    pass
def adjustBackground(*args):
    pass
def setConvergenceDistanceToSelected(*args):
    pass
def selectCamera(*args):
    pass
def currentViewCamera(*args):
    pass
def getValidEditor(panel):
    pass
def uninitialize():
    pass
def currentViewRigFromEditor(editor):
    pass
def switchToSinglePerspLayout():
    pass
def currentViewCameraFromEditor(editor):
    pass
def activeModeAvailable(*args):
    pass
def switchToCameraSet(*args):
    pass
def switchToOutlinerPerspLayout():
    pass
def swapCamerasState(*args):
    pass
def swapCameras(*args):
    pass
def switchToSelected(*args):
    pass