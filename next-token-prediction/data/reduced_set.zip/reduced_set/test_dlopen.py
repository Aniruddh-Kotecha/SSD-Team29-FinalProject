import py
from cffi import FFI, VerificationError, CDefError
from cffi.recompiler import make_py_source
from testing.udir import udir
def test_simple():
    ffi = FFI()
    ffi.cdef("int close(int); static const int BB = 42; int somevar;")
    target = udir.join('test_simple.py')
    make_py_source(ffi, 'test_simple', str(target))
    assert target.read() == r
def test_global_constant():
    ffi = FFI()
    ffi.cdef("static const long BB; static const float BF = 12;")
    target = udir.join('test_valid_global_constant.py')
    make_py_source(ffi, 'test_valid_global_constant', str(target))
    assert target.read() == r
def test_invalid_global_constant_3():
    ffi = FFI()
    e = py.test.raises(CDefError, ffi.cdef, "
    assert str(e.value).startswith(
        "only supports one of the following syntax:")
def test_invalid_dotdotdot_in_macro():
    ffi = FFI()
    ffi.cdef("
    target = udir.join('test_invalid_dotdotdot_in_macro.py')
    e = py.test.raises(VerificationError, make_py_source, ffi,
                       'test_invalid_dotdotdot_in_macro', str(target))
    assert str(e.value) == ("macro FOO: cannot use the syntax '...' in "
                            "'
def test_typename():
    ffi = FFI()
    ffi.cdef("typedef int foobar_t;")
    target = udir.join('test_typename.py')
    make_py_source(ffi, 'test_typename', str(target))
    assert target.read() == r
def test_enum():
    ffi = FFI()
    ffi.cdef("enum myenum_e { AA, BB, CC=-42 };")
    target = udir.join('test_enum.py')
    make_py_source(ffi, 'test_enum', str(target))
    assert target.read() == r
def test_struct():
    ffi = FFI()
    ffi.cdef("struct foo_s { int a; signed char b[]; }; struct bar_s;")
    target = udir.join('test_struct.py')
    make_py_source(ffi, 'test_struct', str(target))
    assert target.read() == r
def test_include():
    ffi = FFI()
    ffi.cdef("
    ffi.set_source('test_include', None)
    target = udir.join('test_include.py')
    make_py_source(ffi, 'test_include', str(target))
    assert target.read() == r
    ffi2 = FFI()
    ffi2.include(ffi)
    target2 = udir.join('test2_include.py')
    make_py_source(ffi2, 'test2_include', str(target2))
    assert target2.read() == r
def test_negative_constant():
    ffi = FFI()
    ffi.cdef("static const int BB = -42;")
    target = udir.join('test_negative_constant.py')
    make_py_source(ffi, 'test_negative_constant', str(target))
    assert target.read() == r
def test_struct_included():
    baseffi = FFI()
    baseffi.cdef("struct foo_s { int x; };")
    baseffi.set_source('test_struct_included_base', None)
    ffi = FFI()
    ffi.include(baseffi)
    target = udir.join('test_struct_included.py')
    make_py_source(ffi, 'test_struct_included', str(target))
    assert target.read() == r
def test_no_cross_include():
    baseffi = FFI()
    baseffi.set_source('test_no_cross_include_base', "..source..")
    ffi = FFI()
    ffi.include(baseffi)
    target = udir.join('test_no_cross_include.py')
    py.test.raises(VerificationError, make_py_source,
                   ffi, 'test_no_cross_include', str(target))
def test_array():
    ffi = FFI()
    ffi.cdef("typedef int32_t my_array_t[42];")
    target = udir.join('test_array.py')
    make_py_source(ffi, 'test_array', str(target))
    assert target.read() == r
def test_array_overflow():
    ffi = FFI()
    ffi.cdef("typedef int32_t my_array_t[3000000000];")
    target = udir.join('test_array_overflow.py')
    py.test.raises(OverflowError, make_py_source,
                   ffi, 'test_array_overflow', str(target))
def test_global_var():
    ffi = FFI()
    ffi.cdef("int myglob;")
    target = udir.join('test_global_var.py')
    make_py_source(ffi, 'test_global_var', str(target))
    assert target.read() == r
def test_bitfield():
    ffi = FFI()
    ffi.cdef("struct foo_s { int y:10; short x:5; };")
    target = udir.join('test_bitfield.py')
    make_py_source(ffi, 'test_bitfield', str(target))
    assert target.read() == r