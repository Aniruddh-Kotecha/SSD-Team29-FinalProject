from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_nym_patrol_strong_hum_m.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","human_base_male")		
	return result