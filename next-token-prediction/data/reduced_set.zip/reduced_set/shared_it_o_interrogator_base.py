from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/creature/npc/droid/shared_it_o_interrogator_base.iff"
	result.attribute_template_id = 3
	result.stfName("droid_name","it_o_interrogator_base")		
	return result