from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/player/city/shared_garden_dantooine_lrg_01.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","garden")		
	return result