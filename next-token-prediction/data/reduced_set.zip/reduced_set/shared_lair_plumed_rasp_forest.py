from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/plumed_rasp/shared_lair_plumed_rasp_forest.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","plumed_rasp_forest")		
	return result