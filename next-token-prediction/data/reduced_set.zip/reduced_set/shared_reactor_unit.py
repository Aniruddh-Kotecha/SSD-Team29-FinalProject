from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/component/vehicle/shared_reactor_unit.iff"
	result.attribute_template_id = -1
	result.stfName("craft_item_ingredients_n","reactor_unit")		
	return result