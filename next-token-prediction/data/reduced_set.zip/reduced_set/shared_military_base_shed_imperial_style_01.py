from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/military/shared_military_base_shed_imperial_style_01.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","military_guard_tower_1")		
	return result