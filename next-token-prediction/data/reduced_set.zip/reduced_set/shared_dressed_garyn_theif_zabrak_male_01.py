from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_garyn_theif_zabrak_male_01.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","zabrak_base_male")		
	return result