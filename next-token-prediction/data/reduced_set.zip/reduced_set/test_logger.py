from twisted.trial import unittest
from .._levels import InvalidLogLevelError
from .._levels import LogLevel
from .._format import formatEvent
from .._logger import Logger
from .._global import globalLogPublisher
class TestLogger(Logger):
    def emit(self, level, format=None, **kwargs):
        def observer(event):
            self.event = event
        globalLogPublisher.addObserver(observer)
        try:
            Logger.emit(self, level, format, **kwargs)
        finally:
            globalLogPublisher.removeObserver(observer)
        self.emitted = {
            "level": level,
            "format": format,
            "kwargs": kwargs,
        }
class LogComposedObject(object):
    log = TestLogger()
    def __init__(self, state=None):
        self.state = state
    def __str__(self):
        return "<LogComposedObject {state}>".format(state=self.state)
class LoggerTests(unittest.TestCase):
    def test_repr(self):
        namespace = "bleargh"
        log = Logger(namespace)
        self.assertEqual(repr(log), "<Logger {0}>".format(repr(namespace)))
    def test_namespaceDefault(self):
        log = Logger()
        self.assertEqual(log.namespace, __name__)
    def test_namespaceAttribute(self):
        obj = LogComposedObject()
        expectedNamespace = "{0}.{1}".format(
            obj.__module__,
            obj.__class__.__name__,
        )
        self.assertEqual(obj.log.namespace, expectedNamespace)
        self.assertEqual(LogComposedObject.log.namespace, expectedNamespace)
        self.assertIs(LogComposedObject.log.source, LogComposedObject)
        self.assertIs(obj.log.source, obj)
        self.assertIs(Logger().source, None)
    def test_descriptorObserver(self):
        observed = []
        class MyObject(object):
            log = Logger(observer=observed.append)
        MyObject.log.info("hello")
        self.assertEqual(len(observed), 1)
        self.assertEqual(observed[0]['log_format'], "hello")
    def test_sourceAvailableForFormatting(self):
        obj = LogComposedObject("hello")
        log = obj.log
        log.error("Hello, {log_source}.")
        self.assertIn("log_source", log.event)
        self.assertEqual(log.event["log_source"], obj)
        stuff = formatEvent(log.event)
        self.assertIn("Hello, <LogComposedObject hello>.", stuff)
    def test_basicLogger(self):
        log = TestLogger()
        for level in LogLevel.iterconstants():
            format = "This is a {level_name} message"
            message = format.format(level_name=level.name)
            logMethod = getattr(log, level.name)
            logMethod(format, junk=message, level_name=level.name)
            self.assertEqual(log.emitted["level"], level)
            self.assertEqual(log.emitted["format"], format)
            self.assertEqual(log.emitted["kwargs"]["junk"], message)
            self.assertTrue(hasattr(log, "event"), "No event observed.")
            self.assertEqual(log.event["log_format"], format)
            self.assertEqual(log.event["log_level"], level)
            self.assertEqual(log.event["log_namespace"], __name__)
            self.assertEqual(log.event["log_source"], None)
            self.assertEqual(log.event["junk"], message)
            self.assertEqual(formatEvent(log.event), message)
    def test_sourceOnClass(self):
        def observer(event):
            self.assertEqual(event["log_source"], Thingo)
        class Thingo(object):
            log = TestLogger(observer=observer)
        Thingo.log.info()
    def test_sourceOnInstance(self):
        def observer(event):
            self.assertEqual(event["log_source"], thingo)
        class Thingo(object):
            log = TestLogger(observer=observer)
        thingo = Thingo()
        thingo.log.info()
    def test_sourceUnbound(self):
        def observer(event):
            self.assertEqual(event["log_source"], None)
        log = TestLogger(observer=observer)
        log.info()
    def test_defaultFailure(self):
        log = TestLogger()
        try:
            raise RuntimeError("baloney!")
        except RuntimeError:
            log.failure("Whoops")
        errors = self.flushLoggedErrors(RuntimeError)
        self.assertEqual(len(errors), 1)
        self.assertEqual(log.emitted["level"], LogLevel.critical)
        self.assertEqual(log.emitted["format"], "Whoops")
    def test_conflictingKwargs(self):
        log = TestLogger()
        log.warn(
            u"*",
            log_format="
            log_level=LogLevel.error,
            log_namespace="*namespace*",
            log_source="*source*",
        )
        self.assertEqual(log.event["log_format"], u"*")
        self.assertEqual(log.event["log_level"], LogLevel.warn)
        self.assertEqual(log.event["log_namespace"], log.namespace)
        self.assertEqual(log.event["log_source"], None)
    def test_logInvalidLogLevel(self):
        log = TestLogger()
        log.emit("*bogus*")
        errors = self.flushLoggedErrors(InvalidLogLevelError)
        self.assertEqual(len(errors), 1)
    def test_trace(self):
        def publisher(event):
            observer(event)
        def observer(event):
            self.assertEqual(event["log_trace"], [(log, publisher)])
        log = TestLogger(observer=publisher)
        log.info("Hello.", log_trace=[])