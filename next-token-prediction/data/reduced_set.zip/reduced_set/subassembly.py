from pycascading.helpers import *
def main():
    flow = Flow()
    repeats = flow.source(Hfs(TextDelimited(Fields(['col1', 'col2']), ' ',
                                            [String, Integer]),
                              'pycascading_data/repeats.txt'))
    output = flow.tsv_sink('pycascading_data/out')
    repeats | native.unique(Fields.ALL) | output
    flow.run()