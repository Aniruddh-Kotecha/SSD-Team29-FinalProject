from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_aakuan_sentinal_rodian_male_01.iff"
	result.attribute_template_id = 9
	result.stfName("npc_name","rodian_base_male")		
	return result