from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/engine/shared_engine_ubrikkian_n2.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","eng_ubrikkian_n2_n")		
	return result