from ooi.occi.core import attribute as attr
from ooi.occi.core import kind
from ooi.occi.core import link
from ooi.occi import helpers
class StorageLink(link.Link):
    attributes = attr.AttributeCollection(["occi.storagelink.deviceid",
                                           "occi.storagelink.mountpoint",
                                           "occi.storagelink.state"])
    kind = kind.Kind(helpers.build_scheme('infrastructure'), 'storagelink',
                     'storage link resource', attributes, 'storagelink/',
                     related=[link.Link.kind])
    def __init__(self, source, target, deviceid=None, mountpoint=None,
                 state=None):
        link_id = '_'.join([source.id, target.id])
        super(StorageLink, self).__init__(None, [], source, target, link_id)
        self.attributes["occi.storagelink.deviceid"] = attr.MutableAttribute(
            "occi.storagelink.deviceid", deviceid)
        self.attributes["occi.storagelink.mountpoint"] = attr.MutableAttribute(
            "occi.storagelink.mountpoint", mountpoint)
        self.attributes["occi.storagelink.state"] = attr.InmutableAttribute(
            "occi.storagelink.state", state)
    @property
    def deviceid(self):
        return self.attributes["occi.storagelink.deviceid"].value
    @deviceid.setter
    def deviceid(self, value):
        self.attributes["occi.storagelink.deviceid"].value = value
    @property
    def mountpoint(self):
        return self.attributes["occi.storagelink.mountpoint"].value
    @mountpoint.setter
    def mountpoint(self, value):
        self.attributes["occi.storagelink.mountpoint"].value = value
    @property
    def state(self):
        return self.attributes["occi.storagelink.state"].value