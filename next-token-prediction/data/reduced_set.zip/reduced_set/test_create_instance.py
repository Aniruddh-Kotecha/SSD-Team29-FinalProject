from awscli.testutils import BaseAWSCommandParamsTest
import awscli.clidriver
class TestCreateInstance(BaseAWSCommandParamsTest):
    prefix = 'opsworks create-instance'
    def test_simple(self):
        cmdline = self.prefix
        cmdline += ' --stack-id f623987f-6303-4bba-a38e-63073e85c726'
        cmdline += ' --layer-ids cb27894d-35f3-4435-b422-6641a785fa4a'
        cmdline += ' --instance-type c1.medium'
        cmdline += ' --hostname aws-client-instance'
        result = {'StackId': 'f623987f-6303-4bba-a38e-63073e85c726',
                  'Hostname': 'aws-client-instance',
                  'LayerIds': ['cb27894d-35f3-4435-b422-6641a785fa4a'],
                  'InstanceType': 'c1.medium'}
        self.assert_params_for_cmd(cmdline, result)
if __name__ == "__main__":
    unittest.main()