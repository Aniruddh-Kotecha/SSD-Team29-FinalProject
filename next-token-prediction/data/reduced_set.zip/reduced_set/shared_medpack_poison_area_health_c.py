from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/medicine/crafted/shared_medpack_poison_area_health_c.iff"
	result.attribute_template_id = 7
	result.stfName("medicine_name","medic_poison_area_health_c")		
	return result