from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/deed/event_perk/shared_treasure_crate_chest_deed.iff"
	result.attribute_template_id = 2
	result.stfName("event_perk","treasure_crate_chest_deed_name")		
	return result