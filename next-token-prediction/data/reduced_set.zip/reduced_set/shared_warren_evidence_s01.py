from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/mission/quest_item/shared_warren_evidence_s01.iff"
	result.attribute_template_id = -1
	result.stfName("warren_item_n","evidence_s01")		
	return result