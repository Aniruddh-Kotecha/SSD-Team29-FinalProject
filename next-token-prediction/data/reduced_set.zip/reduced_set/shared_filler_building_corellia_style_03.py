from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/corellia/shared_filler_building_corellia_style_03.iff"
	result.attribute_template_id = -1
	result.stfName("building_name","filler_building_corellia_style_3")		
	return result