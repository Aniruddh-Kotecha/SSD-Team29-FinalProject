from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/furniture/jedi/shared_frn_all_table_light_01.iff"
	result.attribute_template_id = 6
	result.stfName("frn_n","frn_all_jedi_table")		
	return result