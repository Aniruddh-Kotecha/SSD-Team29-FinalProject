from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/crafted/repair/shared_repair_kit_hull.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","repair_kit_hull_d")		
	return result