from bok_choy.promise import BrokenPromise
from bok_choy.web_app_test import WebAppTest
from .pages import AjaxPage, AjaxNoJQueryPage
class AjaxTest(WebAppTest):
    def setUp(self):
        super(AjaxTest, self).setUp()
        self.ajax = AjaxPage(self.browser)
        self.ajax.visit()
    def test_ajax(self):
        self.ajax.click_button()
        self.ajax.wait_for_ajax()
        self.assertEquals(self.ajax.output, "Loaded via an ajax call.")
    def test_ajax_too_slow(self):
        self.ajax.browser.execute_script('jQuery.active=1')
        with self.assertRaises(BrokenPromise) as exc:
            self.ajax.wait_for_ajax(timeout=1)
        self.assertEqual(
            'Promise not satisfied: Finished waiting for ajax requests.',
            exc.exception.__str__())
class AjaxNoJQueryTest(WebAppTest):
    def setUp(self):
        super(AjaxNoJQueryTest, self).setUp()
        self.ajax = AjaxNoJQueryPage(self.browser)
        self.ajax.visit()
    def test_ajax_with_slow_jquery(self):
        with self.assertRaises(BrokenPromise) as exc:
            self.ajax.wait_for_ajax(timeout=1)
        self.assertEqual(
            'Promise not satisfied: Finished waiting for ajax requests.',
            exc.exception.__str__())