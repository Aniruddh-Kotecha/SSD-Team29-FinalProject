from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/ship/components/droid_interface/shared_ddi_hk_mk2.iff"
	result.attribute_template_id = 8
	result.stfName("space/space_item","ddi_hk_mk2_n")		
	return result