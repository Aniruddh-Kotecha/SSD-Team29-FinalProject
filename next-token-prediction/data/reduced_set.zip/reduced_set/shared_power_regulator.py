from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/hq_destructible/shared_power_regulator.iff"
	result.attribute_template_id = -1
	result.stfName("hq","power_regulator")		
	return result