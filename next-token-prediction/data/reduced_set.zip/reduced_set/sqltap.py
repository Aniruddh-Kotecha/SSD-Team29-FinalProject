from __future__ import division
import datetime
import time
import traceback
import collections
import sys
import os
try:
    import queue
except ImportError:
    import Queue as queue
import mako.exceptions
import mako.template
import mako.lookup
import sqlalchemy.engine
import sqlalchemy.event
import sqlparse
REPORT_HTML = "html"
REPORT_WSGI = "wsgi"
REPORT_TEXT = "text"
_py2 = sys.version_info[0] == 2
def format_sql(sql):
    try:
        return sqlparse.format(sql, reindent=True)
    except Exception:
        return sql
class QueryStats(object):
    def __init__(self, text, stack, start_time, end_time,
                 user_context, params_dict, results):
        self.text = text
        self.params = params_dict
        self.params_id = None
        self.stack = self.stack_text = stack
        self.start_time = start_time
        self.end_time = end_time
        self.duration = end_time - start_time
        self.user_context = user_context
        self.rowcount = results.rowcount
        self.params_hash = self.calculate_params_hash(self.params)
    @classmethod
    def calculate_params_hash(cls, params):
        h = 0
        for k in sorted(params.keys()):
            h ^= 10009 * hash(repr(params[k]))
        return (h ^ (h >> 32)) & ((1 << 32) - 1)
    def __repr__(self):
        return ("<%s text='%s...' params=%r "
                "duration=%.3f rowcount=%d params_hash=%08x>" % (
                    self.__class__.__name__, str(self.text)[:40], self.params,
                    self.duration, self.rowcount, self.params_hash))
class ProfilingSession(object):
    def __init__(self, engine=sqlalchemy.engine.Engine, user_context_fn=None,
                 collect_fn=None):
        self.started = False
        self.engine = engine
        self.user_context_fn = user_context_fn
        if collect_fn:
            self.collector = None
            self.collect_fn = collect_fn
        else:
            self.collector = queue.Queue(0)
            self.collect_fn = self.collector.put
    def _before_exec(self, conn, clause, multiparams, params):
        conn._sqltap_query_start_time = time.time()
    def _after_exec(self, conn, clause, multiparams, params, results):
        end_time = time.time()
        start_time = getattr(conn, '_sqltap_query_start_time', end_time)
        context = (None if not self.user_context_fn
                   else self.user_context_fn(
                        conn, clause, multiparams, params, results))
        try:
            text = clause.compile(dialect=conn.engine.dialect)
        except AttributeError:
            text = clause
        params_dict = self._extract_parameters_from_results(results)
        stack = traceback.extract_stack()[:-1]
        qstats = QueryStats(text, stack, start_time, end_time,
                            context, params_dict, results)
        self.collect_fn(qstats)
    def _extract_parameters_from_results(self, query_results):
        params_dict = {}
        for p in getattr(query_results.context, 'compiled_parameters', []):
            params_dict.update(p)
        return params_dict
    def collect(self):
        if not self.collector:
            raise AssertionError("Can't call collect when you've registered "
                                 "your own collect_fn!")
        queries = []
        try:
            while True:
                queries.append(self.collector.get(block=False))
        except queue.Empty:
            pass
        return queries
    def start(self):
        if self.started is True:
            raise AssertionError("Profiling session is already started!")
        self.started = True
        sqlalchemy.event.listen(self.engine, "before_execute",
                                self._before_exec)
        sqlalchemy.event.listen(self.engine, "after_execute", self._after_exec)
    def stop(self):
        if self.started is False:
            raise AssertionError("Profiling session is already stopped")
        self.started = False
        sqlalchemy.event.remove(self.engine, "before_execute",
                                self._before_exec)
        sqlalchemy.event.remove(self.engine, "after_execute", self._after_exec)
    def __enter__(self, *args, **kwargs):
        self.start()
        return self
    def __exit__(self, *args, **kwargs):
        self.stop()
    def __call__(self, fn):
        def decorated(*args, **kwargs):
            with self:
                return fn(*args, **kwargs)
        return decorated
class QueryGroup(object):
    ParamsID = 1
    def __init__(self):
        self.queries = []
        self.stacks = collections.defaultdict(int)
        self.params_hashes = {}
        self.callers = {}
        self.max = 0
        self.min = sys.maxsize
        self.sum = 0
        self.rowcounts = 0
        self.mean = 0
        self.median = 0
    def find_user_fn(self, stack):
        for frame in reversed(stack):
            if 'sqlalchemy' not in frame[0]:
                return frame
    def add(self, q):
        if not bool(self.queries):
            self.text = str(q.text)
            self.formatted_text = format_sql(self.text)
            self.first_word = self.text.split()[0]
        self.queries.append(q)
        self.stacks[q.stack_text] += 1
        self.callers[q.stack_text] = self.find_user_fn(q.stack)
        self.max = max(self.max, q.duration)
        self.min = min(self.min, q.duration)
        self.sum += q.duration
        self.rowcounts += q.rowcount
        self.mean = self.sum / len(self.queries)
        self.add_params(q)
    def add_params(self, q):
        key = (hash(q.text), q.params_hash)
        count, params_id, params = self.params_hashes.get(
            key, (0, None, q.params))
        if params_id is None:
            self.__class__.ParamsID += 1
            params_id = self.ParamsID
        self.params_hashes[key] = (count + 1, params_id, params)
        q.params_id = q.params_id or params_id
    def calc_median(self):
        queries = sorted(self.queries, key=lambda q: q.duration,
                         reverse=True)
        length = len(queries)
        if not length % 2:
            x1 = queries[length // 2].duration
            x2 = queries[length // 2 - 1].duration
            self.median = (x1 + x2) / 2
        else:
            self.median = queries[length // 2].duration
class Reporter(object):
    REPORT_TITLE = "SQLTap Profiling Report"
    def __init__(self, stats, report_file=None, report_dir=".",
                 template_file=None, template_dir=None, **kwargs):
        self.duration = ((stats[-1].end_time - stats[0].start_time)
                         if stats else 0)
        self.stats = stats
        self.report_file = report_file
        self.report_dir = report_dir
        self.template_file = template_file
        self.template_dir = template_dir
        self.kwargs = kwargs
        self._process_stats()
    def render(self, ex_handler=mako.exceptions.html_error_template):
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            result = self.template.render(
                query_groups=self._query_groups,
                all_group=self._all_group,
                report_title=self.REPORT_TITLE,
                report_time=current_time,
                duration=self.duration,
                **self.kwargs)
        except Exception:
            return ex_handler().render()
        return result
    def report(self, log_mode='w'):
        content = self.render()
        if self.report_file:
            report_file = os.path.join(self.report_dir, self.report_file)
            if _py2:
                content = content.encode('utf8')
            with open(report_file, log_mode) as f:
                f.write(content)
        return content
    def _init_template(self, template_filters=['unicode', 'h']):
        if self.template_file is None:
            raise Exception("SQLTap Report template file not specified!")
        if self.template_dir is None:
            self.template_dir = os.path.join(os.path.dirname(__file__),
                                             "templates")
        lookup = mako.lookup.TemplateLookup(self.template_dir,
                                            default_filters=template_filters)
        self.template = lookup.get_template(self.template_file)
    def _process_stats(self):
        query_groups = collections.defaultdict(QueryGroup)
        all_group = QueryGroup()
        for qstats in self.stats:
            qstats.stack_text = \
                ''.join(traceback.format_list(qstats.stack)).strip()
            group = query_groups[str(qstats.text)]
            group.add(qstats)
            all_group.add(qstats)
        query_groups = sorted(query_groups.values(), key=lambda g: g.sum,
                              reverse=True)
        for g in query_groups:
            g.calc_median()
        self._query_groups = query_groups
        self._all_group = all_group
class HTMLReporter(Reporter):
    def __init__(self, stats, report_file=None, report_dir=".",
                 template_file="html.mako", template_dir=None, **kwargs):
        super(HTMLReporter, self).__init__(
            stats,
            report_file=report_file,
            report_dir=report_dir,
            template_file=template_file,
            template_dir=template_dir,
            **kwargs)
        self._init_template(template_filters=['unicode', 'h'])
class WSGIReporter(HTMLReporter):
    def __init__(self, stats, report_file=None, report_dir=".",
                 template_file="wsgi.mako", template_dir=None, **kwargs):
        super(WSGIReporter, self).__init__(
            stats,
            report_file=report_file,
            report_dir=report_dir,
            template_file=template_file,
            template_dir=template_dir,
            **kwargs)
class TextReporter(Reporter):
    def __init__(self, stats, report_file=None, report_dir=".",
                 template_file="text.mako", template_dir=None, **kwargs):
        super(TextReporter, self).__init__(
            stats,
            report_file=report_file,
            report_dir=report_dir,
            template_file=template_file,
            template_dir=template_dir,
            **kwargs)
        self._init_template(template_filters=['unicode'])
    def render(self):
        return super(TextReporter, self).render(
            ex_handler=mako.exceptions.text_error_template)
    def report(self):
        return super(TextReporter, self).report(log_mode='a')
def start(engine=sqlalchemy.engine.Engine, user_context_fn=None,
          collect_fn=None):
    session = ProfilingSession(engine, user_context_fn, collect_fn)
    session.start()
    return session
def report(statistics, filename=None, template="html.mako", **kwargs):
    REPORTER_MAPPING = {REPORT_HTML: HTMLReporter,
                        REPORT_WSGI: WSGIReporter,
                        REPORT_TEXT: TextReporter}
    report_format = kwargs.get('report_format')
    if report_format:
        report_format = report_format.lower()
        if report_format not in REPORTER_MAPPING.keys():
            raise Exception("Format |%s| is not valid! formats supported: %s ",
                            (report_format, REPORTER_MAPPING.keys()))
        reporter = REPORTER_MAPPING[report_format](
            statistics, report_file=filename, **kwargs)
    else:
        reporter = HTMLReporter(
            statistics, report_file=filename, template_file=template, **kwargs)
    result = reporter.report()
    return result
def _hotfix_dispatch_remove():
    import sqlalchemy
    if sqlalchemy.__version__ >= "0.9.4":
        return
    from sqlalchemy.event.attr import _DispatchDescriptor
    from sqlalchemy.event import registry
    def remove(self, event_key):
        target = event_key.dispatch_target
        stack = [target]
        while stack:
            cls = stack.pop(0)
            stack.extend(cls.__subclasses__())
            if cls in self._clslevel:
                self._clslevel[cls].remove(event_key._listen_fn)
        registry._removed_from_collection(event_key, self)
    _DispatchDescriptor.remove = remove
_hotfix_dispatch_remove()