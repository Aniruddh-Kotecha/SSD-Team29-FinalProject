import unittest
from google.appengine.tools.devappserver2 import start_response_utils
class TestCapturingStartResponse(unittest.TestCase):
  def test_success(self):
    start_response = start_response_utils.CapturingStartResponse()
    stream = start_response('200 OK', [('header1', 'value1')])
    stream.write('Hello World!')
    self.assertEqual('200 OK', start_response.status)
    self.assertEqual(None, start_response.exc_info)
    self.assertEqual([('header1', 'value1')], start_response.response_headers)
    self.assertEqual('Hello World!', start_response.response_stream.getvalue())
  def test_exception(self):
    exc_info = (object(), object(), object())
    start_response = start_response_utils.CapturingStartResponse()
    start_response('200 OK', [('header1', 'value1')])
    start_response('500 Internal Server Error', [], exc_info)
    self.assertEqual('500 Internal Server Error', start_response.status)
    self.assertEqual(exc_info, start_response.exc_info)
    self.assertEqual([], start_response.response_headers)
  def test_merged_response(self):
    start_response = start_response_utils.CapturingStartResponse()
    stream = start_response('200 OK', [('header1', 'value1')])
    stream.write('Hello World!')
    self.assertEqual('Hello World! Goodbye World!',
                     start_response.merged_response([' Goodbye ', 'World!']))
if __name__ == '__main__':
  unittest.main()