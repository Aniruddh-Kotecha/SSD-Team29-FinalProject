from django import template
register = template.Library()
@register.inclusion_tag("rg_number.html")
def redgreen(collection):
	if not collection:
		return {"valid":False}
	if not isinstance(collection,dict):
		return {"valid":True, "text":collection, "show_red":False, "debug":collection, "color":False}
	if not collection or "value" not in collection:
		return {"valid":False}
	value = collection["value"]
	treshold = collection.get("treshold", 0)
	low_is_red = collection.get("red_is_low", False)
	color = collection.get("color", True)
	if callable(treshold):
		above_treshold = treshold(value, collection)
	else:
		above_treshold = value > treshold
	if above_treshold:
		show_red = not low_is_red
	else:
		show_red = low_is_red
	args = {
			"valid":True,
			"text":value, 
			"show_red":show_red,
			"color":color, 
			"debug":(value, low_is_red, above_treshold, collection.get("values",None))
			}
	if "link" in collection:
		args["link"] = collection["link"];
	return args
@register.inclusion_tag("color_value.html")
def color_value(collection):
	if not collection:
		return {"valid":False}
	if not isinstance(collection,dict):
		return {"valid":True, "text":collection, "color":None, "debug":collection}
	if not collection or "value" not in collection:
		return {"valid":False}
	value = collection["value"]
	color = collection.get("textcolor", None)
	if callable(color):
		(value, color) = color(value, collection)
	args = {
			"valid":True,
			"text":value, 
			"color":color,
			"debug":(value, color, collection.get("color", None), collection.get("values",None))
			}
	if "link" in collection:
		args["link"] = collection["link"];
	return args