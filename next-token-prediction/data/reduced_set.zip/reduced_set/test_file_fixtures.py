import sys
import unittest
from test.file_fixtures import ComputeFileFixtures
class FileFixturesTests(unittest.TestCase):
    def test_success(self):
        f = ComputeFileFixtures('meta')
        self.assertEqual("Hello, World!", f.load('helloworld.txt'))
    def test_failure(self):
        f = ComputeFileFixtures('meta')
        self.assertRaises(IOError, f.load, 'nil')
if __name__ == '__main__':
    sys.exit(unittest.main())