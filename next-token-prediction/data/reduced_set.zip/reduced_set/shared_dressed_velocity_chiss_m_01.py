from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_velocity_chiss_m_01.iff"
	result.attribute_template_id = 9
	result.stfName("obj_n","unknown_creature")		
	return result