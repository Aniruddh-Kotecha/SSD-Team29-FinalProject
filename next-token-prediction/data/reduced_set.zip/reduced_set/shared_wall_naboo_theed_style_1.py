from swgpy.object import *	
def create(kernel):
	result = Static()
	result.template = "object/static/structure/naboo/shared_wall_naboo_theed_style_1.iff"
	result.attribute_template_id = -1
	result.stfName("obj_n","unknown_object")		
	return result