import argparse
import sys
import json
import logging
from prelert.engineApiClient import EngineApiClient
HOST = 'localhost'
PORT = 8080
BASE_URL = 'engine/v1'
def setupLogging():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
def parseArguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", help="The Prelert Engine API host, defaults to "
        + HOST, default=HOST)    
    parser.add_argument("--port", help="The Prelert Engine API port, defaults to " 
        + str(PORT), default=PORT)
    parser.add_argument("file", help="Path to farequote.csv")
    return parser.parse_args()   
def main():
    setupLogging()
    args = parseArguments()
    engine_client = EngineApiClient(args.host, BASE_URL, args.port)
    job_config = '{"analysisConfig" : {\
                        "bucketSpan":3600,\
                        "detectors" :[{"function":"metric","fieldName":"responsetime","byFieldName":"airline"}] },\
                        "dataDescription" : {"fieldDelimiter":",", "timeField":"time", "timeFormat":"yyyy-MM-dd HH:mm:ssX"} }'
    logging.info("Creating job")
    (http_status_code, response) = engine_client.createJob(job_config)
    if http_status_code != 201:
        print (http_status_code, json.dumps(response))
        return
    job_id = response['id']
    logging.info("Uploading data to " + job_id)
    file = open(args.file, 'rb')
    (http_status_code, response) = engine_client.upload(job_id, file)
    if http_status_code != 202:
        print (http_status_code, json.dumps(response))
        return
    logging.info("Closing job " + job_id)
    (http_status_code, response) = engine_client.close(job_id)
    if http_status_code != 202:
        print (http_status_code, json.dumps(response))
        return
    logging.info("Get result buckets for job " + job_id)
    (http_status_code, response) = engine_client.getAllBuckets(job_id)
    if http_status_code != 200:
        print (http_status_code, json.dumps(response))
    else:
        print "Date,Anomaly Score,Max Normalized Probablility"
        for bucket in response:                                
            print "{0},{1},{2}".format(bucket['timestamp'], bucket['anomalyScore'], 
                        bucket['maxNormalizedProbability'])
if __name__ == "__main__":
    main()    