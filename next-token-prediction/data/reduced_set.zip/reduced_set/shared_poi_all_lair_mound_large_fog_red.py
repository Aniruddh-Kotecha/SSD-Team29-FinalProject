from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/lair/base/shared_poi_all_lair_mound_large_fog_red.iff"
	result.attribute_template_id = -1
	result.stfName("lair_n","mound")		
	return result