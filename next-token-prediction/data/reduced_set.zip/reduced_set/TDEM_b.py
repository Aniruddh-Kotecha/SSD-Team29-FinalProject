from BaseTDEM import BaseTDEMProblem, FieldsTDEM
from SimPEG.Utils import mkvc, sdiag
import numpy as np
from SurveyTDEM import SurveyTDEM
class FieldsTDEM_e_from_b(FieldsTDEM):
    knownFields = {'b': 'F'}
    aliasFields = {'e': ['b','E','e_from_b']}
    def startup(self):
        self.MeSigmaI  = self.survey.prob.MeSigmaI
        self.edgeCurlT = self.survey.prob.mesh.edgeCurl.T
        self.MfMui     = self.survey.prob.MfMui
    def e_from_b(self, b, srcInd, timeInd):
        return self.MeSigmaI*(self.edgeCurlT*(self.MfMui*b))
class FieldsTDEM_e_from_b_Ah(FieldsTDEM):
    knownFields = {'b': 'F'}
    aliasFields = {'e': ['b','E','e_from_b']}
    p = None
    def startup(self):
        self.MeSigmaI  = self.survey.prob.MeSigmaI
        self.edgeCurlT = self.survey.prob.mesh.edgeCurl.T
        self.MfMui     = self.survey.prob.MfMui
    def e_from_b(self, y_b, srcInd, tInd):
        y_e = self.MeSigmaI*(self.edgeCurlT*(self.MfMui*y_b))
        if 'e' in self.p:
            y_e = y_e - self.MeSigmaI*self.p[srcInd,'e',tInd]
        return y_e
class ProblemTDEM_b(BaseTDEMProblem):
    def __init__(self, mesh, mapping=None, **kwargs):
        BaseTDEMProblem.__init__(self, mesh, mapping=mapping, **kwargs)
    solType = 'b'
    surveyPair = SurveyTDEM
    _FieldsForward_pair = FieldsTDEM_e_from_b
    def getA(self, tInd):
        dt = self.timeSteps[tInd]
        return self.MfMui*self.mesh.edgeCurl*self.MeSigmaI*self.mesh.edgeCurl.T*self.MfMui + (1.0/dt)*self.MfMui
    def getRHS(self, tInd, F):
        dt = self.timeSteps[tInd]
        B_n = np.c_[[F[src,'b',tInd] for src in self.survey.srcList]].T
        if B_n.shape[0] is not 1:
            raise NotImplementedError('getRHS not implemented for this shape of B_n')
        RHS = (1.0/dt)*self.MfMui*B_n[0,:,:]
        return RHS
    def Gvec(self, m, vec, u=None):
        if u is None:
            u = self.fields(m)
        self.curModel = m
        p = FieldsTDEM(self.mesh, self.survey)
        p[:, 'e', 0] = 0.0
        dMdsig = self.MeSigmaDeriv
        for i in range(1,self.nT+1):
            for src in self.survey.srcList:
                p[src, 'e', i] = - dMdsig(u[src,'e',i]) *  vec
        return p
    def Gtvec(self, m, vec, u=None):
        if u is None:
            u = self.fields(m)
        self.curModel = m
        MeSigmaDeriv = self.MeSigmaDeriv
        nSrc = self.survey.nSrc
        VUs = None
        for i in range(1,self.nT+1):
            vu = None
            for src in self.survey.srcList:
                vusrc = MeSigmaDeriv(u[src,'e',i]).T * vec[src,'e',i]
                vu = vusrc if vu is None else vu + vusrc
            VUs = vu if VUs is None else VUs + vu
        return -VUs
    def solveAh(self, m, p):
        def AhRHS(tInd, y):
            rhs = self.MfMui*(self.mesh.edgeCurl*(self.MeSigmaI*p[:,'e',tInd+1]))
            if 'b' in p:
                rhs = rhs + p[:,'b',tInd+1]
            if tInd == 0:
                return rhs
            dt = self.timeSteps[tInd]
            return rhs + 1.0/dt*self.MfMui*y[:,'b',tInd]
        F = FieldsTDEM_e_from_b_Ah(self.mesh, self.survey, p=p)
        return self.forward(m, AhRHS, F)
    def solveAht(self, m, p):
        def AhtRHS(tInd, y):
            nSrc, nF = self.survey.nSrc, self.mesh.nF
            rhs = np.zeros((nF,1) if nSrc == 1 else (nF, nSrc))
            if 'e' in p:
                rhs += self.MfMui*(self.mesh.edgeCurl*(self.MeSigmaI*p[:,'e',tInd+1]))
            if 'b' in p:
                rhs += p[:,'b',tInd+1]
            if tInd == self.nT-1:
                return rhs
            dt = self.timeSteps[tInd+1]
            return rhs + 1.0/dt*self.MfMui*y[:,'b',tInd+2]
        F = FieldsTDEM_e_from_b_Ah(self.mesh, self.survey, p=p)
        return self.adjoint(m, AhtRHS, F)
    def _AhVec(self, m, vec):
        self.curModel = m
        f = FieldsTDEM(self.mesh, self.survey)
        for i in range(1,self.nT+1):
            dt = self.timeSteps[i-1]
            b = 1.0/dt*self.MfMui*vec[:,'b',i] + self.MfMui*(self.mesh.edgeCurl*vec[:,'e',i])
            if i > 1:
                b = b - 1.0/dt*self.MfMui*vec[:,'b',i-1]
            f[:,'b',i] = b
            f[:,'e',i] = self.mesh.edgeCurl.T*(self.MfMui*vec[:,'b',i]) - self.MeSigma*vec[:,'e',i]
        return f
    def _AhtVec(self, m, vec):
        self.curModel = m
        f = FieldsTDEM(self.mesh, self.survey)
        for i in range(self.nT):
            b = 1.0/self.timeSteps[i]*self.MfMui*vec[:,'b',i+1] + self.MfMui*(self.mesh.edgeCurl*vec[:,'e',i+1])
            if i < self.nT-1:
                b = b - 1.0/self.timeSteps[i+1]*self.MfMui*vec[:,'b',i+2]
            f[:,'b', i+1] = b
            f[:,'e', i+1] = self.mesh.edgeCurl.T*(self.MfMui*vec[:,'b',i+1]) - self.MeSigma*vec[:,'e',i+1]
        return f