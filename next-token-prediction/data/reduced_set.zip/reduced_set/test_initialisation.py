import unittest
from ...compatibility import StringIO
from ...chartsheet import Chartsheet
class TestInitialisation(unittest.TestCase):
    def setUp(self):
        self.fh = StringIO()
        self.chartsheet = Chartsheet()
        self.chartsheet._set_filehandle(self.fh)
    def test_xml_declaration(self):
        self.chartsheet._xml_declaration()
        exp = 
        got = self.fh.getvalue()
        self.assertEqual(got, exp)