__author__  = "Jonas Berg"
__email__   = "pyhys@users.sourceforge.net"
__license__ = "Apache License, Version 2.0"
import unittest
import tests
if __name__ == '__main__':
    suite = tests.suite_all_simulated()
    unittest.TextTestRunner(verbosity=0).run(suite)