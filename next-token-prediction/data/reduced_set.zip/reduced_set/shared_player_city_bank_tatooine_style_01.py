from swgpy.object import *	
def create(kernel):
	result = Building()
	result.template = "object/building/player/shared_player_city_bank_tatooine_style_01.iff"
	result.attribute_template_id = -1
	result.stfName("","")		
	return result