from multiprocessing import Process, Queue
from odmtools.controller.logicPlotOptions import Probability, BoxWhisker, Statistics
import time
from odmtools.odmservices import SeriesService
__author__ = 'jmeline'
import logging
from odmtools.common.logger import LoggerTool
tool = LoggerTool()
logger = tool.setupLogger(__name__, __name__ + '.log', 'w', logging.DEBUG)
class TaskServerMP:
    def __init__(self, numproc):
        self.numprocesses = numproc
        self.keepgoing = True
        self.dispatcher = Dispatcher()
        self.Processes = []
        self.tasks = []
        self.numtasks = len(self.tasks)
        self.completedTasks = {}
        for n in range(self.numprocesses):
            process = Process(target=TaskServerMP.worker, args=(self.dispatcher,))
            process.start()
            self.Processes.append(process)
    def setTasks(self, taskList):
        self.tasks.extend(taskList)
        self.numtasks = len(taskList)
    def processTasks(self):
        for i in self.tasks:
            self.dispatcher.putTask(i)
    def getOutput(self):
        logger.debug("Trying to get something...")
        output = self.dispatcher.getResult()
        logger.debug("Got %s, %s" % output)
        self.completedTasks[output[0]] = output[1]
    def getCompletedTasks(self):
        for _ in range(len(self.tasks)):
            self.getOutput()
        self.tasks = []
        return self.completedTasks
    def anyAlive(self):
        isalive = False
        for n in range(self.numprocesses):
            isalive = (isalive or self.Processes[n].is_alive())
        return isalive
    def processTerminate(self):
        for n in range(self.numprocesses):
            self.Processes[n].terminate()
        while (self.anyAlive()):
            time.sleep(0.5)
    def worker(cls, dispatcher):
        while True:
            arg = dispatcher.getTask()
            task_type = arg[0]
            task = arg[1]
            result = arg
            if task_type == "Probability":
                result = Probability(task)
            if task_type == "BoxWhisker":
                result = BoxWhisker(task[0], task[1])
            if task_type == "Summary":
                result = Statistics(task)
            if task_type == "InitEditValues":
                connection = SeriesService("sqlite:///:memory:")
                df = task[1]
                logger.debug("Load series from db")
                df.to_sql(name="DataValues", con=connection._session_factory.engine, flavor='sqlite', index = False, chunksize = 10000)
                logger.debug("done loading database")
                result = connection
            if task_type == "UpdateEditDF":
                connection = task[1]
                result = connection.get_all_values_df()
            result = (task_type, result)
            dispatcher.putResult(result)
    worker = classmethod(worker)
    def worker_sp(self):
class Dispatcher:
    def __init__(self):
        self.taskQueue = Queue()
        self.resultQueue = Queue()
    def getTaskQueue(self):
        return self.taskQueue
    def getResultQueue(self):
        return self.resultQueue
    def putTask(self, task):
        self.taskQueue.put(task)
    def getTask(self):
        return self.taskQueue.get()
    def putResult(self, output):
        self.resultQueue.put(output)
    def getResult(self):
        return self.resultQueue.get()