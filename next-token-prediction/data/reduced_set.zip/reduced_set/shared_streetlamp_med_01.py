from swgpy.object import *	
def create(kernel):
	result = Tangible()
	result.template = "object/tangible/furniture/city/shared_streetlamp_med_01.iff"
	result.attribute_template_id = 6
	result.stfName("frn_n","streetlamp_3")		
	return result