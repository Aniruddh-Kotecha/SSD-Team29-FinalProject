try:
  import json
except ImportError:
  import simplejson as json
from createsend import CreateSendBase, BadRequest
from utils import json_to_py
class Subscriber(CreateSendBase):
  def __init__(self, auth=None, list_id=None, email_address=None):
    self.list_id = list_id
    self.email_address = email_address
    super(Subscriber, self).__init__(auth)
  def get(self, list_id=None, email_address=None):
    params = { "email": email_address or self.email_address }
    response = self._get("/subscribers/%s.json" % (list_id or self.list_id), params=params)
    return json_to_py(response)
  def add(self, list_id, email_address, name, custom_fields, resubscribe, restart_subscription_based_autoresponders=False):
    body = {
      "EmailAddress": email_address,
      "Name": name,
      "CustomFields": custom_fields,
      "Resubscribe": resubscribe,
      "RestartSubscriptionBasedAutoresponders": restart_subscription_based_autoresponders }
    response = self._post("/subscribers/%s.json" % list_id, json.dumps(body))
    return json_to_py(response)
  def update(self, new_email_address, name, custom_fields, resubscribe, restart_subscription_based_autoresponders=False):
    params = { "email": self.email_address }
    body = {
      "EmailAddress": new_email_address,
      "Name": name,
      "CustomFields": custom_fields,
      "Resubscribe": resubscribe,
      "RestartSubscriptionBasedAutoresponders": restart_subscription_based_autoresponders }
    response = self._put("/subscribers/%s.json" % self.list_id,
      body=json.dumps(body), params=params)
    self.email_address = new_email_address
  def import_subscribers(self, list_id, subscribers, resubscribe, queue_subscription_based_autoresponders=False, restart_subscription_based_autoresponders=False):
    body = {
      "Subscribers": subscribers,
      "Resubscribe": resubscribe,
      "QueueSubscriptionBasedAutoresponders": queue_subscription_based_autoresponders,
      "RestartSubscriptionBasedAutoresponders": restart_subscription_based_autoresponders }
    try:
      response = self._post("/subscribers/%s/import.json" % list_id, json.dumps(body))
    except BadRequest, br:
      if hasattr(br.data, 'ResultData'):
        return br.data.ResultData
      else:
        raise br
    return json_to_py(response)
  def unsubscribe(self):
    body = {
      "EmailAddress": self.email_address }
    response = self._post("/subscribers/%s/unsubscribe.json" % self.list_id, json.dumps(body))
  def history(self):
    params = { "email": self.email_address }
    response = self._get("/subscribers/%s/history.json" % self.list_id, params=params)
    return json_to_py(response)
  def delete(self):
    params = { "email": self.email_address }
    response = self._delete("/subscribers/%s.json" % self.list_id, params=params)