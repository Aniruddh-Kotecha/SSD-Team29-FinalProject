from swgpy.object import *	
def create(kernel):
	result = Creature()
	result.template = "object/mobile/shared_dressed_tatooine_jabba_henchman.iff"
	result.attribute_template_id = 9
	result.stfName("theme_park_name","jabba_henchman")		
	return result