import itertools
import networkx as nx
from nose.tools import assert_true
from networkx.algorithms.bipartite.matching import eppstein_matching
from networkx.algorithms.bipartite.matching import hopcroft_karp_matching
from networkx.algorithms.bipartite.matching import maximum_matching
from networkx.algorithms.bipartite.matching import to_vertex_cover
class TestMatching():
    def setup(self):
        edges = [(0, 7), (0, 8), (2, 6), (2, 9), (3, 8), (4, 8), (4, 9),
                 (5, 11)]
        self.graph = nx.Graph()
        self.graph.add_nodes_from(range(12))
        self.graph.add_edges_from(edges)
    def check_match(self, matching):
        M = matching
        matched_vertices = frozenset(itertools.chain(*M.items()))
        assert matched_vertices == frozenset(range(12)) - {1, 10}
        assert all(u == M[M[u]] for u in range(12) if u in M)
    def check_vertex_cover(self, vertices):
        assert len(vertices) == 5
        for (u, v) in self.graph.edges():
            assert u in vertices or v in vertices
    def test_eppstein_matching(self):
        self.check_match(eppstein_matching(self.graph))
    def test_hopcroft_karp_matching(self):
        self.check_match(hopcroft_karp_matching(self.graph))
    def test_to_vertex_cover(self):
        matching = maximum_matching(self.graph)
        vertex_cover = to_vertex_cover(self.graph, matching)
        self.check_vertex_cover(vertex_cover)
def test_eppstein_matching():
    """Test in accordance to issue
    G = nx.Graph()
    G.add_nodes_from(['a', 2, 3, 4], bipartite=0)
    G.add_nodes_from([1, 'b', 'c'], bipartite=1)
    G.add_edges_from([('a', 1), ('a', 'b'), (2, 'b'),
                      (2, 'c'), (3, 'c'), (4, 1)])
    matching = eppstein_matching(G)
    assert_true(len(matching)==len(maximum_matching(G)))
    assert all(x in set(matching.keys()) for x in set(matching.values()))