from pygments.style import Style
from pygments.token import Token, Comment, Name, Keyword, Generic, Number, Operator, String
BASE03 = '
BASE02 = '
BASE01 = '
BASE00 = '
BASE0 = '
BASE1 = '
BASE2 = '
BASE3 = '
YELLOW = '
ORANGE = '
RED = '
MAGENTA = '
VIOLET = '
BLUE = '
CYAN = '
GREEN = '
class SolarizedStyle(Style):
    background_color = BASE03
    styles = {
        Keyword: GREEN,
        Keyword.Constant: ORANGE,
        Keyword.Declaration: BLUE,
        Keyword.Reserved: BLUE,
        Keyword.Type: RED,
        Name.Attribute: BASE1,
        Name.Builtin: YELLOW,
        Name.Builtin.Pseudo: BLUE,
        Name.Class: BLUE,
        Name.Constant: ORANGE,
        Name.Decorator: BLUE,
        Name.Entity: ORANGE,
        Name.Exception: ORANGE,
        Name.Function: BLUE,
        Name.Tag: BLUE,
        Name.Variable: BLUE,
        String: CYAN,
        String.Backtick: BASE01,
        String.Char: CYAN,
        String.Doc: BASE1,
        String.Escape: ORANGE,
        String.Heredoc: BASE1,
        String.Regex: RED,
        Number: CYAN,
        Operator: GREEN,
        Comment: BASE01,
        Comment.Preproc: GREEN,
        Comment.Special: GREEN,
        Generic.Deleted: CYAN,
        Generic.Emph: 'italic',
        Generic.Error: RED,
        Generic.Heading: ORANGE,
        Generic.Inserted: GREEN,
        Generic.Strong: 'bold',
        Generic.Subheading: ORANGE,
        Token: BASE1,
        Token.Other: ORANGE,
    }